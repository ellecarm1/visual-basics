﻿Public Class SummaryForm
    Private Sub Ok_Button_Click(sender As Object, e As EventArgs) Handles Ok_Button.Click
        'closes this window only
        Close()
    End Sub

    Private Sub SummaryForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Total_Smoothies_Label.Text = SmoothieForm.totalsmoothies.ToString
        Total_receipts_Label.Text = SmoothieForm.totalreceipts.ToString("C2")
    End Sub
End Class