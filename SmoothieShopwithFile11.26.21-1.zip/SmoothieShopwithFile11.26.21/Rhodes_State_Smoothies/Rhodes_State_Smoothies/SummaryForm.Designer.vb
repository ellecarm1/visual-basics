﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SummaryForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Ok_Button = New System.Windows.Forms.Button()
        Me.Total_receipts_Label = New System.Windows.Forms.Label()
        Me.Total_Smoothies_Label = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Ok_Button
        '
        Me.Ok_Button.Location = New System.Drawing.Point(185, 244)
        Me.Ok_Button.Name = "Ok_Button"
        Me.Ok_Button.Size = New System.Drawing.Size(75, 23)
        Me.Ok_Button.TabIndex = 0
        Me.Ok_Button.Text = "OK"
        Me.Ok_Button.UseVisualStyleBackColor = True
        '
        'Total_receipts_Label
        '
        Me.Total_receipts_Label.BackColor = System.Drawing.Color.White
        Me.Total_receipts_Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Total_receipts_Label.Location = New System.Drawing.Point(229, 183)
        Me.Total_receipts_Label.Name = "Total_receipts_Label"
        Me.Total_receipts_Label.Size = New System.Drawing.Size(103, 23)
        Me.Total_receipts_Label.TabIndex = 1
        '
        'Total_Smoothies_Label
        '
        Me.Total_Smoothies_Label.BackColor = System.Drawing.Color.White
        Me.Total_Smoothies_Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Total_Smoothies_Label.Location = New System.Drawing.Point(229, 119)
        Me.Total_Smoothies_Label.Name = "Total_Smoothies_Label"
        Me.Total_Smoothies_Label.Size = New System.Drawing.Size(103, 23)
        Me.Total_Smoothies_Label.TabIndex = 2
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(80, 129)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(110, 13)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Total Smoothies Sold:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(80, 193)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(76, 13)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Total Receipts"
        '
        'SummaryForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(458, 356)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Total_Smoothies_Label)
        Me.Controls.Add(Me.Total_receipts_Label)
        Me.Controls.Add(Me.Ok_Button)
        Me.Name = "SummaryForm"
        Me.Text = "SummaryForm"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Ok_Button As Button
    Friend WithEvents Total_receipts_Label As Label
    Friend WithEvents Total_Smoothies_Label As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
End Class
