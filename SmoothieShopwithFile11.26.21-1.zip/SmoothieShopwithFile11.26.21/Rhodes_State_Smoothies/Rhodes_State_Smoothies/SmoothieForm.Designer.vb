﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class SmoothieForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(SmoothieForm))
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.SpinachCheckBox = New System.Windows.Forms.CheckBox()
        Me.GreenTeaCheckBox = New System.Windows.Forms.CheckBox()
        Me.FlaxseedCheckBox = New System.Windows.Forms.CheckBox()
        Me.VitaminsCheckBox = New System.Windows.Forms.CheckBox()
        Me.ProteinCheckBox = New System.Windows.Forms.CheckBox()
        Me.QuantityTextBox = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SmoothieComboBox = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CalculateOrderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PrintSmoothieFlavorsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ShowSummaryInfoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClearToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddSmoothFlavorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RemoveSmoothieFlavorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Smoothie_Print_Dialog = New System.Windows.Forms.PrintPreviewDialog()
        Me.Smoothie_Document = New System.Drawing.Printing.PrintDocument()
        Me.GroupBox1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Lucida Sans Unicode", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(34, 92)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(418, 23)
        Me.Label5.TabIndex = 32
        Me.Label5.Text = "Stop in today and try our latest flavors."
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Lucida Sans Unicode", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(128, 54)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(230, 28)
        Me.Label4.TabIndex = 30
        Me.Label4.Text = "The best in Lima!"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.SpinachCheckBox)
        Me.GroupBox1.Controls.Add(Me.GreenTeaCheckBox)
        Me.GroupBox1.Controls.Add(Me.FlaxseedCheckBox)
        Me.GroupBox1.Controls.Add(Me.VitaminsCheckBox)
        Me.GroupBox1.Controls.Add(Me.ProteinCheckBox)
        Me.GroupBox1.Location = New System.Drawing.Point(134, 196)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.GroupBox1.Size = New System.Drawing.Size(219, 193)
        Me.GroupBox1.TabIndex = 27
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Select Additional Add-Ins"
        '
        'SpinachCheckBox
        '
        Me.SpinachCheckBox.AutoSize = True
        Me.SpinachCheckBox.Location = New System.Drawing.Point(8, 141)
        Me.SpinachCheckBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.SpinachCheckBox.Name = "SpinachCheckBox"
        Me.SpinachCheckBox.Size = New System.Drawing.Size(89, 17)
        Me.SpinachCheckBox.TabIndex = 4
        Me.SpinachCheckBox.Text = "Spinach $.25"
        Me.SpinachCheckBox.UseVisualStyleBackColor = True
        '
        'GreenTeaCheckBox
        '
        Me.GreenTeaCheckBox.AutoSize = True
        Me.GreenTeaCheckBox.Location = New System.Drawing.Point(8, 113)
        Me.GreenTeaCheckBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.GreenTeaCheckBox.Name = "GreenTeaCheckBox"
        Me.GreenTeaCheckBox.Size = New System.Drawing.Size(107, 17)
        Me.GreenTeaCheckBox.TabIndex = 3
        Me.GreenTeaCheckBox.Text = "Green Tea $1.00"
        Me.GreenTeaCheckBox.UseVisualStyleBackColor = True
        '
        'FlaxseedCheckBox
        '
        Me.FlaxseedCheckBox.AutoSize = True
        Me.FlaxseedCheckBox.Location = New System.Drawing.Point(8, 87)
        Me.FlaxseedCheckBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.FlaxseedCheckBox.Name = "FlaxseedCheckBox"
        Me.FlaxseedCheckBox.Size = New System.Drawing.Size(92, 17)
        Me.FlaxseedCheckBox.TabIndex = 2
        Me.FlaxseedCheckBox.Text = "Flaxseed $.50"
        Me.FlaxseedCheckBox.UseVisualStyleBackColor = True
        '
        'VitaminsCheckBox
        '
        Me.VitaminsCheckBox.AutoSize = True
        Me.VitaminsCheckBox.Location = New System.Drawing.Point(8, 60)
        Me.VitaminsCheckBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.VitaminsCheckBox.Name = "VitaminsCheckBox"
        Me.VitaminsCheckBox.Size = New System.Drawing.Size(112, 17)
        Me.VitaminsCheckBox.TabIndex = 1
        Me.VitaminsCheckBox.Text = "Vitamin Pack $.75"
        Me.VitaminsCheckBox.UseVisualStyleBackColor = True
        '
        'ProteinCheckBox
        '
        Me.ProteinCheckBox.AutoSize = True
        Me.ProteinCheckBox.Location = New System.Drawing.Point(8, 34)
        Me.ProteinCheckBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.ProteinCheckBox.Name = "ProteinCheckBox"
        Me.ProteinCheckBox.Size = New System.Drawing.Size(122, 17)
        Me.ProteinCheckBox.TabIndex = 0
        Me.ProteinCheckBox.Text = "Protein Powder $.50"
        Me.ProteinCheckBox.UseVisualStyleBackColor = True
        '
        'QuantityTextBox
        '
        Me.QuantityTextBox.Location = New System.Drawing.Point(250, 158)
        Me.QuantityTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.QuantityTextBox.Name = "QuantityTextBox"
        Me.QuantityTextBox.Size = New System.Drawing.Size(132, 20)
        Me.QuantityTextBox.TabIndex = 26
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(250, 136)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(46, 13)
        Me.Label2.TabIndex = 25
        Me.Label2.Text = "Quantity"
        '
        'SmoothieComboBox
        '
        Me.SmoothieComboBox.FormattingEnabled = True
        Me.SmoothieComboBox.Location = New System.Drawing.Point(63, 158)
        Me.SmoothieComboBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.SmoothieComboBox.Name = "SmoothieComboBox"
        Me.SmoothieComboBox.Size = New System.Drawing.Size(160, 21)
        Me.SmoothieComboBox.TabIndex = 24
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(73, 136)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(84, 13)
        Me.Label1.TabIndex = 23
        Me.Label1.Text = "Choose a flavor:"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.EditToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(8, 2, 0, 2)
        Me.MenuStrip1.Size = New System.Drawing.Size(486, 24)
        Me.MenuStrip1.TabIndex = 22
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CalculateOrderToolStripMenuItem, Me.PrintSmoothieFlavorsToolStripMenuItem, Me.ExitToolStripMenuItem, Me.ShowSummaryInfoToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'CalculateOrderToolStripMenuItem
        '
        Me.CalculateOrderToolStripMenuItem.Name = "CalculateOrderToolStripMenuItem"
        Me.CalculateOrderToolStripMenuItem.Size = New System.Drawing.Size(193, 22)
        Me.CalculateOrderToolStripMenuItem.Text = "Calculate Order"
        '
        'PrintSmoothieFlavorsToolStripMenuItem
        '
        Me.PrintSmoothieFlavorsToolStripMenuItem.Name = "PrintSmoothieFlavorsToolStripMenuItem"
        Me.PrintSmoothieFlavorsToolStripMenuItem.Size = New System.Drawing.Size(193, 22)
        Me.PrintSmoothieFlavorsToolStripMenuItem.Text = "Print Smoothie Flavors"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(193, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'ShowSummaryInfoToolStripMenuItem
        '
        Me.ShowSummaryInfoToolStripMenuItem.Name = "ShowSummaryInfoToolStripMenuItem"
        Me.ShowSummaryInfoToolStripMenuItem.Size = New System.Drawing.Size(193, 22)
        Me.ShowSummaryInfoToolStripMenuItem.Text = "Show Summary Info"
        '
        'EditToolStripMenuItem
        '
        Me.EditToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ClearToolStripMenuItem, Me.AddSmoothFlavorToolStripMenuItem, Me.RemoveSmoothieFlavorToolStripMenuItem})
        Me.EditToolStripMenuItem.Name = "EditToolStripMenuItem"
        Me.EditToolStripMenuItem.Size = New System.Drawing.Size(39, 20)
        Me.EditToolStripMenuItem.Text = "Edit"
        '
        'ClearToolStripMenuItem
        '
        Me.ClearToolStripMenuItem.Name = "ClearToolStripMenuItem"
        Me.ClearToolStripMenuItem.Size = New System.Drawing.Size(206, 22)
        Me.ClearToolStripMenuItem.Text = "Clear"
        '
        'AddSmoothFlavorToolStripMenuItem
        '
        Me.AddSmoothFlavorToolStripMenuItem.Name = "AddSmoothFlavorToolStripMenuItem"
        Me.AddSmoothFlavorToolStripMenuItem.Size = New System.Drawing.Size(206, 22)
        Me.AddSmoothFlavorToolStripMenuItem.Text = "Add Smoothie Flavor"
        '
        'RemoveSmoothieFlavorToolStripMenuItem
        '
        Me.RemoveSmoothieFlavorToolStripMenuItem.Name = "RemoveSmoothieFlavorToolStripMenuItem"
        Me.RemoveSmoothieFlavorToolStripMenuItem.Size = New System.Drawing.Size(206, 22)
        Me.RemoveSmoothieFlavorToolStripMenuItem.Text = "Remove Smoothie Flavor"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(107, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'Smoothie_Print_Dialog
        '
        Me.Smoothie_Print_Dialog.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.Smoothie_Print_Dialog.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.Smoothie_Print_Dialog.ClientSize = New System.Drawing.Size(400, 300)
        Me.Smoothie_Print_Dialog.Enabled = True
        Me.Smoothie_Print_Dialog.Icon = CType(resources.GetObject("Smoothie_Print_Dialog.Icon"), System.Drawing.Icon)
        Me.Smoothie_Print_Dialog.Name = "Smoothie_Print_Dialog"
        Me.Smoothie_Print_Dialog.Visible = False
        '
        'Smoothie_Document
        '
        '
        'SmoothieForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(486, 466)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.QuantityTextBox)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.SmoothieComboBox)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Name = "SmoothieForm"
        Me.Text = "Smoothie Shop"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents SpinachCheckBox As CheckBox
    Friend WithEvents GreenTeaCheckBox As CheckBox
    Friend WithEvents FlaxseedCheckBox As CheckBox
    Friend WithEvents VitaminsCheckBox As CheckBox
    Friend WithEvents ProteinCheckBox As CheckBox
    Friend WithEvents QuantityTextBox As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents SmoothieComboBox As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CalculateOrderToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PrintSmoothieFlavorsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EditToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ClearToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AddSmoothFlavorToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RemoveSmoothieFlavorToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Smoothie_Print_Dialog As PrintPreviewDialog
    Friend WithEvents Smoothie_Document As Printing.PrintDocument
    Friend WithEvents ShowSummaryInfoToolStripMenuItem As ToolStripMenuItem
End Class
