﻿'Ellena Carmean
'City Water Bill Calculator
'10/5/2021

Option Strict On

Public Class Form1
    Private Const water_rate_charge As Decimal = 0.00175D
    Private Sub calcbutton_Click(sender As Object, e As EventArgs) Handles calcbutton.Click
        Try


            'variables'
            Dim current_reading As Integer
            Dim previous_reading As Integer
            Dim gallons_used As Integer
            Dim total_charge As Decimal

            'conversions'
            current_reading = CInt(currentreadinglabel.Text)
            previous_reading = CInt(previousreadinglabel.Text)

            If current_reading < previous_reading Then
                MessageBox.Show("cannot input lesser value in current reading")

            Else
                'calculate total due' 
                gallons_used = current_reading - previous_reading

                'calculate total charge'
                total_charge = gallons_used * water_rate_charge



            End If

            'displays'
            gallonsusedlabel.Text = gallons_used.ToString
            totalchargelabel.Text = total_charge.ToString("c")

        Catch ex As Exception
            MessageBox.Show("please input data") 'this message tells the user to input data'
        End Try
    End Sub
    'this button will clear the form'
    Private Sub clearbutton_Click(sender As Object, e As EventArgs) Handles clearbutton.Click
        currentreadinglabel.Text = ""
        previousreadinglabel.Text = ""
        gallonsusedlabel.Text = ""
        totalchargelabel.Text = ""
    End Sub
End Class
