﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.gallonsusedlabel = New System.Windows.Forms.Label()
        Me.totalchargelabel = New System.Windows.Forms.Label()
        Me.currentreadinglabel = New System.Windows.Forms.TextBox()
        Me.previousreadinglabel = New System.Windows.Forms.TextBox()
        Me.calcbutton = New System.Windows.Forms.Button()
        Me.clearbutton = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(79, 54)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(93, 15)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Current reading:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(79, 109)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(98, 15)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Previous reading:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(74, 301)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(78, 15)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Gallons Used:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(74, 364)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(76, 15)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Total Charge:"
        '
        'gallonsusedlabel
        '
        Me.gallonsusedlabel.BackColor = System.Drawing.Color.Silver
        Me.gallonsusedlabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.gallonsusedlabel.Location = New System.Drawing.Point(193, 290)
        Me.gallonsusedlabel.Name = "gallonsusedlabel"
        Me.gallonsusedlabel.Size = New System.Drawing.Size(76, 26)
        Me.gallonsusedlabel.TabIndex = 4
        '
        'totalchargelabel
        '
        Me.totalchargelabel.BackColor = System.Drawing.Color.Silver
        Me.totalchargelabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.totalchargelabel.Location = New System.Drawing.Point(193, 353)
        Me.totalchargelabel.Name = "totalchargelabel"
        Me.totalchargelabel.Size = New System.Drawing.Size(76, 26)
        Me.totalchargelabel.TabIndex = 5
        '
        'currentreadinglabel
        '
        Me.currentreadinglabel.Location = New System.Drawing.Point(212, 45)
        Me.currentreadinglabel.Name = "currentreadinglabel"
        Me.currentreadinglabel.Size = New System.Drawing.Size(100, 23)
        Me.currentreadinglabel.TabIndex = 6
        '
        'previousreadinglabel
        '
        Me.previousreadinglabel.Location = New System.Drawing.Point(212, 106)
        Me.previousreadinglabel.Name = "previousreadinglabel"
        Me.previousreadinglabel.Size = New System.Drawing.Size(100, 23)
        Me.previousreadinglabel.TabIndex = 7
        '
        'calcbutton
        '
        Me.calcbutton.Location = New System.Drawing.Point(299, 293)
        Me.calcbutton.Name = "calcbutton"
        Me.calcbutton.Size = New System.Drawing.Size(75, 23)
        Me.calcbutton.TabIndex = 8
        Me.calcbutton.Text = "calculate"
        Me.calcbutton.UseVisualStyleBackColor = True
        '
        'clearbutton
        '
        Me.clearbutton.Location = New System.Drawing.Point(299, 356)
        Me.clearbutton.Name = "clearbutton"
        Me.clearbutton.Size = New System.Drawing.Size(75, 23)
        Me.clearbutton.TabIndex = 9
        Me.clearbutton.Text = "clear"
        Me.clearbutton.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(490, 450)
        Me.Controls.Add(Me.clearbutton)
        Me.Controls.Add(Me.calcbutton)
        Me.Controls.Add(Me.previousreadinglabel)
        Me.Controls.Add(Me.currentreadinglabel)
        Me.Controls.Add(Me.totalchargelabel)
        Me.Controls.Add(Me.gallonsusedlabel)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents gallonsusedlabel As Label
    Friend WithEvents totalchargelabel As Label
    Friend WithEvents currentreadinglabel As TextBox
    Friend WithEvents previousreadinglabel As TextBox
    Friend WithEvents calcbutton As Button
    Friend WithEvents clearbutton As Button
End Class
