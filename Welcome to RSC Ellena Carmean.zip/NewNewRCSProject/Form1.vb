﻿Public Class Form1
    Private Sub ExitButton_Click(sender As Object, e As EventArgs) Handles ExitButton.Click
        Close()

    End Sub

    Private Sub NecromancyButton_Click(sender As Object, e As EventArgs) Handles NecromancyButton.Click
        MessageBox.Text = "Ashen Hall"
    End Sub

    Private Sub PotionButton_Click(sender As Object, e As EventArgs) Handles PotionButton.Click
        MessageBox.Text = "River Run Center"
    End Sub

    Private Sub DragonButton_Click(sender As Object, e As EventArgs) Handles DragonButton.Click
        MessageBox.Text = "Dragon Born Gate"
    End Sub

    Private Sub ForagingButton_Click(sender As Object, e As EventArgs) Handles ForagingButton.Click
        MessageBox.Text = "Apple Pie Place"
    End Sub

    Private Sub LoginButton_Click(sender As Object, e As EventArgs) Handles LoginButton.Click
        'display a personal greeting to the user'
        LoginLabel.Text = "Welcome" & UsernameBox.Text
    End Sub

    Private Sub WelcomeForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
