﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim Label1 As System.Windows.Forms.Label
        Me.ExitButton = New System.Windows.Forms.Button()
        Me.NecromancyButton = New System.Windows.Forms.Button()
        Me.PotionButton = New System.Windows.Forms.Button()
        Me.DragonButton = New System.Windows.Forms.Button()
        Me.ForagingButton = New System.Windows.Forms.Button()
        Me.MessageBox = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.UsernameBox = New System.Windows.Forms.TextBox()
        Me.LoginButton = New System.Windows.Forms.Button()
        Me.NameLabel = New System.Windows.Forms.Label()
        Me.LoginLabel = New System.Windows.Forms.Label()
        Me.ActivitiesBox = New System.Windows.Forms.GroupBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.c = New System.Windows.Forms.Label()
        Me.PuppetLabel = New System.Windows.Forms.Label()
        Me.PotLuckLabel = New System.Windows.Forms.Label()
        Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.ActivitiesBox.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Label1.Font = New System.Drawing.Font("Fresh Lychee", 48.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Label1.Location = New System.Drawing.Point(35, 143)
        Label1.Name = "Label1"
        Label1.Size = New System.Drawing.Size(683, 72)
        Label1.TabIndex = 11
        Label1.Text = "YOURE A LIZARD HARRY"
        Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ExitButton
        '
        Me.ExitButton.Location = New System.Drawing.Point(260, 98)
        Me.ExitButton.Name = "ExitButton"
        Me.ExitButton.Size = New System.Drawing.Size(75, 23)
        Me.ExitButton.TabIndex = 0
        Me.ExitButton.Text = "Exit"
        Me.ExitButton.UseVisualStyleBackColor = True
        '
        'NecromancyButton
        '
        Me.NecromancyButton.Location = New System.Drawing.Point(41, 22)
        Me.NecromancyButton.Name = "NecromancyButton"
        Me.NecromancyButton.Size = New System.Drawing.Size(104, 23)
        Me.NecromancyButton.TabIndex = 1
        Me.NecromancyButton.Text = "Necromancy"
        Me.NecromancyButton.UseVisualStyleBackColor = True
        '
        'PotionButton
        '
        Me.PotionButton.Location = New System.Drawing.Point(170, 22)
        Me.PotionButton.Name = "PotionButton"
        Me.PotionButton.Size = New System.Drawing.Size(113, 23)
        Me.PotionButton.TabIndex = 2
        Me.PotionButton.Text = "Potion Making"
        Me.PotionButton.UseVisualStyleBackColor = True
        '
        'DragonButton
        '
        Me.DragonButton.Location = New System.Drawing.Point(310, 22)
        Me.DragonButton.Name = "DragonButton"
        Me.DragonButton.Size = New System.Drawing.Size(126, 23)
        Me.DragonButton.TabIndex = 3
        Me.DragonButton.Text = "Dragon Hunting"
        Me.DragonButton.UseVisualStyleBackColor = True
        '
        'ForagingButton
        '
        Me.ForagingButton.Location = New System.Drawing.Point(463, 22)
        Me.ForagingButton.Name = "ForagingButton"
        Me.ForagingButton.Size = New System.Drawing.Size(75, 23)
        Me.ForagingButton.TabIndex = 4
        Me.ForagingButton.Text = "Foraging"
        Me.ForagingButton.UseVisualStyleBackColor = True
        '
        'MessageBox
        '
        Me.MessageBox.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.MessageBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.MessageBox.Location = New System.Drawing.Point(73, 61)
        Me.MessageBox.Name = "MessageBox"
        Me.MessageBox.Size = New System.Drawing.Size(424, 23)
        Me.MessageBox.TabIndex = 5
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.NecromancyButton)
        Me.GroupBox1.Controls.Add(Me.MessageBox)
        Me.GroupBox1.Controls.Add(Me.ExitButton)
        Me.GroupBox1.Controls.Add(Me.ForagingButton)
        Me.GroupBox1.Controls.Add(Me.PotionButton)
        Me.GroupBox1.Controls.Add(Me.DragonButton)
        Me.GroupBox1.Location = New System.Drawing.Point(79, 491)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(592, 122)
        Me.GroupBox1.TabIndex = 6
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Advisor Search"
        '
        'UsernameBox
        '
        Me.UsernameBox.Location = New System.Drawing.Point(315, 59)
        Me.UsernameBox.Name = "UsernameBox"
        Me.UsernameBox.Size = New System.Drawing.Size(170, 23)
        Me.UsernameBox.TabIndex = 7
        Me.UsernameBox.Text = " "
        '
        'LoginButton
        '
        Me.LoginButton.Location = New System.Drawing.Point(502, 59)
        Me.LoginButton.Name = "LoginButton"
        Me.LoginButton.Size = New System.Drawing.Size(115, 23)
        Me.LoginButton.TabIndex = 8
        Me.LoginButton.Text = "Login"
        Me.LoginButton.UseVisualStyleBackColor = True
        '
        'NameLabel
        '
        Me.NameLabel.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.NameLabel.Location = New System.Drawing.Point(120, 56)
        Me.NameLabel.Name = "NameLabel"
        Me.NameLabel.Size = New System.Drawing.Size(189, 23)
        Me.NameLabel.TabIndex = 9
        Me.NameLabel.Text = "Enter Your Name Here:"
        Me.NameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LoginLabel
        '
        Me.LoginLabel.BackColor = System.Drawing.Color.Peru
        Me.LoginLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LoginLabel.Location = New System.Drawing.Point(152, 109)
        Me.LoginLabel.Name = "LoginLabel"
        Me.LoginLabel.Size = New System.Drawing.Size(424, 23)
        Me.LoginLabel.TabIndex = 10
        '
        'ActivitiesBox
        '
        Me.ActivitiesBox.Controls.Add(Me.Label2)
        Me.ActivitiesBox.Controls.Add(Me.c)
        Me.ActivitiesBox.Controls.Add(Me.PuppetLabel)
        Me.ActivitiesBox.Controls.Add(Me.PotLuckLabel)
        Me.ActivitiesBox.Location = New System.Drawing.Point(120, 218)
        Me.ActivitiesBox.Name = "ActivitiesBox"
        Me.ActivitiesBox.Size = New System.Drawing.Size(497, 267)
        Me.ActivitiesBox.TabIndex = 12
        Me.ActivitiesBox.TabStop = False
        Me.ActivitiesBox.Text = "Activities"
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.SteelBlue
        Me.Label2.Font = New System.Drawing.Font("Pumpkin Story", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label2.ForeColor = System.Drawing.Color.Snow
        Me.Label2.Location = New System.Drawing.Point(32, 199)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(424, 48)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Hobbit Helpers Club"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'c
        '
        Me.c.BackColor = System.Drawing.Color.Maroon
        Me.c.Font = New System.Drawing.Font("Pumpkin Story", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.c.ForeColor = System.Drawing.Color.Snow
        Me.c.Location = New System.Drawing.Point(32, 139)
        Me.c.Name = "c"
        Me.c.Size = New System.Drawing.Size(424, 48)
        Me.c.TabIndex = 2
        Me.c.Text = "Flying Lessons"
        Me.c.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PuppetLabel
        '
        Me.PuppetLabel.BackColor = System.Drawing.Color.SaddleBrown
        Me.PuppetLabel.Font = New System.Drawing.Font("Pumpkin Story", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.PuppetLabel.ForeColor = System.Drawing.Color.Snow
        Me.PuppetLabel.Location = New System.Drawing.Point(32, 79)
        Me.PuppetLabel.Name = "PuppetLabel"
        Me.PuppetLabel.Size = New System.Drawing.Size(424, 48)
        Me.PuppetLabel.TabIndex = 1
        Me.PuppetLabel.Text = "Puppet Theater"
        Me.PuppetLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PotLuckLabel
        '
        Me.PotLuckLabel.BackColor = System.Drawing.Color.RosyBrown
        Me.PotLuckLabel.Font = New System.Drawing.Font("Pumpkin Story", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.PotLuckLabel.ForeColor = System.Drawing.Color.Snow
        Me.PotLuckLabel.Location = New System.Drawing.Point(32, 19)
        Me.PotLuckLabel.Name = "PotLuckLabel"
        Me.PotLuckLabel.Size = New System.Drawing.Size(424, 48)
        Me.PotLuckLabel.TabIndex = 0
        Me.PotLuckLabel.Text = "Pot Luck - Town"
        Me.PotLuckLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(740, 640)
        Me.Controls.Add(Me.ActivitiesBox)
        Me.Controls.Add(Label1)
        Me.Controls.Add(Me.LoginLabel)
        Me.Controls.Add(Me.NameLabel)
        Me.Controls.Add(Me.LoginButton)
        Me.Controls.Add(Me.UsernameBox)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "Welcome to RSC"
        Me.GroupBox1.ResumeLayout(False)
        Me.ActivitiesBox.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ExitButton As Button
    Friend WithEvents NecromancyButton As Button
    Friend WithEvents PotionButton As Button
    Friend WithEvents DragonButton As Button
    Friend WithEvents ForagingButton As Button
    Friend WithEvents MessageBox As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents UsernameBox As TextBox
    Friend WithEvents LoginButton As Button
    Friend WithEvents NameLabel As Label
    Friend WithEvents LoginLabel As Label
    Friend WithEvents ActivitiesBox As GroupBox
    Friend WithEvents PuppetLabel As Label
    Friend WithEvents PotLuckLabel As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents c As Label
End Class
