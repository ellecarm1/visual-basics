﻿Option Strict On
'Ellena Carmean'
'Visual Basics'
'9/24/2021'
Public Class Form1
    'these are class level constants that represent points possible'
    Private Const POINTS_POSSIBLE_ONE As Decimal = 72D
    Private Const POINTS_POSSIBLE_TWO As Decimal = 90D
    Private Const POINTS_POSSIBLE_THREE As Decimal = 57D
    Const TOTAL_POSSIBLE As Decimal = 219D

    Private Sub CalcButton_Click(sender As Object, e As EventArgs) Handles CalcButton.Click
        'variables that we get from the user'
        Dim STUDENT_GRADE_ONE As Decimal
        Dim STUDENT_GRADE_TWO As Decimal
        Dim STUDENT_GRADE_THREE As Decimal
        Dim TOTAL_RESULTS As Decimal

        Dim RESULT_ONE As Decimal
        Dim RESULT_TWO As Decimal
        Dim RESULT_THREE As Decimal

        'convert'
        STUDENT_GRADE_ONE = CDec(TestOneTextBox.Text)
        STUDENT_GRADE_TWO = CDec(TestTwoTextBox.Text)
        STUDENT_GRADE_THREE = CDec(TestThreeTextBox.Text)

        'Math'
        'we need student grade one divided by points possible equals total results label for each score' 
        RESULT_ONE = STUDENT_GRADE_ONE / POINTS_POSSIBLE_ONE
        RESULT_TWO = STUDENT_GRADE_TWO / POINTS_POSSIBLE_TWO
        RESULT_THREE = STUDENT_GRADE_THREE / POINTS_POSSIBLE_THREE

        TOTAL_RESULTS = (STUDENT_GRADE_ONE + STUDENT_GRADE_TWO + STUDENT_GRADE_THREE) / TOTAL_POSSIBLE


        'OUTPUT'
        ResultOneLabelBox.Text = RESULT_ONE.ToString("p2")
        ResultTwoLabelBox.Text = RESULT_TWO.ToString("p2")
        ResultThreeLabelBox.Text = RESULT_THREE.ToString("p2")
        TotalResultsLabel.Text = "Your final grade for the class is " & TOTAL_RESULTS.ToString("p2")


    End Sub

    Private Sub ExitButton_Click(sender As Object, e As EventArgs) Handles ExitButton.Click
        Close()
        'This button closes the program when clicked'
    End Sub

    Private Sub ClearButton_Click(sender As Object, e As EventArgs) Handles ClearButton.Click
        TestOneTextBox.Clear()
        TestTwoTextBox.Clear()
        TestThreeTextBox.Clear()
        ResultOneLabelBox.Text = ""
        ResultTwoLabelBox.Text = ""
        ResultThreeLabelBox.Text = ""
        TotalResultsLabel.Text = ""
        'This button clears the data inputed when clicked'
    End Sub

    Private Sub TestOneTextBox_TextChanged(sender As Object, e As EventArgs) Handles TestOneTextBox.TextChanged
        TestOneTextBox.Select()
        'This method will reset the cursor'
    End Sub
End Class
