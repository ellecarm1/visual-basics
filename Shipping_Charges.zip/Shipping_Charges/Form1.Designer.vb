﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Oz_Textbox = New System.Windows.Forms.TextBox()
        Me.WeightLabel = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Pound_Textbox = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Total_Processed_Label = New System.Windows.Forms.Label()
        Me.Average_Cost_Label = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Total_Cost_Label = New System.Windows.Forms.Label()
        Me.CalcButton = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Clear_Left_Side_Button = New System.Windows.Forms.Button()
        Me.Clear_All_Button = New System.Windows.Forms.Button()
        Me.Shipping_Charges_Label = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Oz_Textbox
        '
        Me.Oz_Textbox.Location = New System.Drawing.Point(317, 176)
        Me.Oz_Textbox.Name = "Oz_Textbox"
        Me.Oz_Textbox.Size = New System.Drawing.Size(57, 23)
        Me.Oz_Textbox.TabIndex = 1
        '
        'WeightLabel
        '
        Me.WeightLabel.AutoSize = True
        Me.WeightLabel.Location = New System.Drawing.Point(49, 184)
        Me.WeightLabel.Name = "WeightLabel"
        Me.WeightLabel.Size = New System.Drawing.Size(45, 15)
        Me.WeightLabel.TabIndex = 2
        Me.WeightLabel.Text = "Weight"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(134, 184)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(20, 15)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "lb."
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(294, 184)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(22, 15)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "oz."
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(49, 249)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(173, 15)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Shipping Charges for this entry:"
        '
        'Pound_Textbox
        '
        Me.Pound_Textbox.Location = New System.Drawing.Point(157, 176)
        Me.Pound_Textbox.Name = "Pound_Textbox"
        Me.Pound_Textbox.Size = New System.Drawing.Size(100, 23)
        Me.Pound_Textbox.TabIndex = 0
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(432, 92)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(82, 15)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Summary Info"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(432, 128)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(176, 15)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Number of packages processed:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(432, 241)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(142, 15)
        Me.Label6.TabIndex = 9
        Me.Label6.Text = "Average cost per package"
        '
        'Total_Processed_Label
        '
        Me.Total_Processed_Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Total_Processed_Label.Location = New System.Drawing.Point(614, 128)
        Me.Total_Processed_Label.Name = "Total_Processed_Label"
        Me.Total_Processed_Label.Size = New System.Drawing.Size(82, 15)
        Me.Total_Processed_Label.TabIndex = 10
        '
        'Average_Cost_Label
        '
        Me.Average_Cost_Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Average_Cost_Label.Location = New System.Drawing.Point(614, 243)
        Me.Average_Cost_Label.Name = "Average_Cost_Label"
        Me.Average_Cost_Label.Size = New System.Drawing.Size(82, 15)
        Me.Average_Cost_Label.TabIndex = 11
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(432, 184)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(168, 15)
        Me.Label9.TabIndex = 12
        Me.Label9.Text = "Total Cost to ship all packages:"
        '
        'Total_Cost_Label
        '
        Me.Total_Cost_Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Total_Cost_Label.Location = New System.Drawing.Point(614, 184)
        Me.Total_Cost_Label.Name = "Total_Cost_Label"
        Me.Total_Cost_Label.Size = New System.Drawing.Size(82, 15)
        Me.Total_Cost_Label.TabIndex = 13
        '
        'CalcButton
        '
        Me.CalcButton.Location = New System.Drawing.Point(115, 317)
        Me.CalcButton.Name = "CalcButton"
        Me.CalcButton.Size = New System.Drawing.Size(75, 23)
        Me.CalcButton.TabIndex = 14
        Me.CalcButton.Text = "Calculate"
        Me.CalcButton.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(229, 317)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 15
        Me.Button1.Text = "Exit"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Clear_Left_Side_Button
        '
        Me.Clear_Left_Side_Button.Location = New System.Drawing.Point(115, 367)
        Me.Clear_Left_Side_Button.Name = "Clear_Left_Side_Button"
        Me.Clear_Left_Side_Button.Size = New System.Drawing.Size(75, 23)
        Me.Clear_Left_Side_Button.TabIndex = 16
        Me.Clear_Left_Side_Button.Text = "Clear"
        Me.Clear_Left_Side_Button.UseVisualStyleBackColor = True
        '
        'Clear_All_Button
        '
        Me.Clear_All_Button.Location = New System.Drawing.Point(229, 367)
        Me.Clear_All_Button.Name = "Clear_All_Button"
        Me.Clear_All_Button.Size = New System.Drawing.Size(75, 23)
        Me.Clear_All_Button.TabIndex = 17
        Me.Clear_All_Button.Text = "Clear All"
        Me.Clear_All_Button.UseVisualStyleBackColor = True
        '
        'Shipping_Charges_Label
        '
        Me.Shipping_Charges_Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Shipping_Charges_Label.Location = New System.Drawing.Point(234, 249)
        Me.Shipping_Charges_Label.Name = "Shipping_Charges_Label"
        Me.Shipping_Charges_Label.Size = New System.Drawing.Size(82, 15)
        Me.Shipping_Charges_Label.TabIndex = 18
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Shipping_Charges_Label)
        Me.Controls.Add(Me.Clear_All_Button)
        Me.Controls.Add(Me.Clear_Left_Side_Button)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.CalcButton)
        Me.Controls.Add(Me.Total_Cost_Label)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Average_Cost_Label)
        Me.Controls.Add(Me.Total_Processed_Label)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.WeightLabel)
        Me.Controls.Add(Me.Oz_Textbox)
        Me.Controls.Add(Me.Pound_Textbox)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Oz_Textbox As TextBox
    Friend WithEvents WeightLabel As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Pound_Textbox As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Total_Processed_Label As Label
    Friend WithEvents Average_Cost_Label As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Total_Cost_Label As Label
    Friend WithEvents CalcButton As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Clear_Left_Side_Button As Button
    Friend WithEvents Clear_All_Button As Button
    Friend WithEvents Shipping_Charges_Label As Label
End Class
