﻿
Option Strict On
'ellena carmean'
'shipping project'
'10/4/21'
Public Class Form1
    Private Num_of_packages_processed As Integer 'this will be written out like total clicks'
    Private Const Rate_To_Ship_Per_OZ As Decimal = 0.12D
    Private total_shipping_for_all As Decimal



    Private Sub CalcButton_Click(sender As Object, e As EventArgs) Handles CalcButton.Click
        'this is user inputted variables'
        Dim Ounces As Decimal
        Dim Pounds As Decimal
        Dim TOTAL_SINGLE_SHIPPING_CHARGE As Decimal
        Dim AVERAGE_COST As Decimal

        'conversions'
        Ounces = CDec(Oz_Textbox.Text)
        Pounds = CInt(Pound_Textbox.Text)

        'calculations'

        TOTAL_SINGLE_SHIPPING_CHARGE = (Ounces * Rate_To_Ship_Per_OZ) + (Pounds / 16)
        Num_of_packages_processed += 1
        total_shipping_for_all += TOTAL_SINGLE_SHIPPING_CHARGE
        AVERAGE_COST = total_shipping_for_all / Num_of_packages_processed
        'display'
        Shipping_Charges_Label.Text = TOTAL_SINGLE_SHIPPING_CHARGE.ToString("c")
        Total_Processed_Label.Text = Num_of_packages_processed.ToString
        Total_Cost_Label.Text = total_shipping_for_all.ToString
        Average_Cost_Label.Text = AVERAGE_COST.ToString("c")
        Pound_Textbox.Text = Pounds.ToString
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'this button closes the program'
        Close()
    End Sub

    Private Sub Clear_Left_Side_Button_Click(sender As Object, e As EventArgs) Handles Clear_Left_Side_Button.Click
        'this button will clear select forms'
        Pound_Textbox.Clear()
        Oz_Textbox.Clear()
        Shipping_Charges_Label.Text = ""
    End Sub

    Private Sub Clear_All_Button_Click(sender As Object, e As EventArgs) Handles Clear_All_Button.Click
        'clear all will clear all forms'
        Pound_Textbox.Clear()
        Oz_Textbox.Clear()
        Shipping_Charges_Label.Text = ""
        Total_Processed_Label.Text = ""
        Total_Cost_Label.Text = ""
        Average_Cost_Label.Text = ""
    End Sub
End Class
