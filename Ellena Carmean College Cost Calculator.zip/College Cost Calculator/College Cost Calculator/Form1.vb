﻿'Ellena Carmean'
'College Cost Calculator'
'9/28/21'
Option Strict On


Public Class Form1
    'THESE ARE CONSTANTS THAT NEED TO HAVE A LONGER LIFETIME THAN VARIABLES'
    Private Const CREDIT_HOUR_RATE = 125D
    Private NUMBER_OF_STUDENTS_PROCESSED As Integer
    Private TOTAL_COST_FOR_ONE_STUDENT As Decimal
    Private TOTAL_COST_FOR_ALL_STUDENTS As Decimal
    Private Sub CalcButton_Click(sender As Object, e As EventArgs) Handles CalcButton.Click
        'THESE ARE VARIABLES INPUTED BY THE USER'
        Dim CREDIT_HOURS As Integer
        Dim BOOK_COST As Decimal
        Dim ROOM_AND_BOARD As Decimal
        Dim MISC_EXPENSES As Decimal
        Dim COST_OF_TUITION As Decimal
        Dim AVERAGE_COST As Decimal
        Try
            'THESES ARE CONVERSIONS SO THE PROGRAM KNOWS WHERE THE DATA IS BEING STORED'
            CREDIT_HOURS = CInt(NumOfCreditHoursTextBox.Text)
            BOOK_COST = CDec(CostOfBooksTextBox.Text)
            ROOM_AND_BOARD = CDec(CostOfBooksTextBox.Text)
            MISC_EXPENSES = CDec(MiscellaneousExpensesTextBox.Text)
        Catch ex As Exception
            MessageBox.Show("please enter numerical value")
        End Try
        'MATH'
        COST_OF_TUITION = CREDIT_HOUR_RATE * CREDIT_HOURS
        Cost_Of_Tuition_Label.Text = COST_OF_TUITION.ToString("c")
        TOTAL_COST_FOR_ONE_STUDENT = BOOK_COST + ROOM_AND_BOARD + MISC_EXPENSES + COST_OF_TUITION

        NUMBER_OF_STUDENTS_PROCESSED += 1
        TOTAL_COST_FOR_ALL_STUDENTS += TOTAL_COST_FOR_ONE_STUDENT

        'display'
        Total_Cost_For_All_Students_LabelBox.Text = TOTAL_COST_FOR_ALL_STUDENTS.ToString("C")
        Num_Of_Students_Processed_LabelBox.Text = NUMBER_OF_STUDENTS_PROCESSED.ToString
        Total_Cost_For_Student_LabelBox.Text = TOTAL_COST_FOR_ONE_STUDENT.ToString("c")

        AVERAGE_COST = TOTAL_COST_FOR_ALL_STUDENTS / NUMBER_OF_STUDENTS_PROCESSED
        Average_Cost_Per_Student_LabelBox.Text = AVERAGE_COST.ToString("C")

    End Sub

    Private Sub ExitButton_Click(sender As Object, e As EventArgs) Handles ExitButton.Click
        Close()

    End Sub

    Private Sub ClearButton_Click(sender As Object, e As EventArgs) Handles ClearButton.Click
        NumOfCreditHoursTextBox.Clear()
        CostOfBooksTextBox.Clear()
        RoomAndBoardTextBox.Clear()
        MiscellaneousExpensesTextBox.Clear()
        Cost_Of_Tuition_Label.Text = ""
        Total_Cost_For_Student_LabelBox.Text = ""

    End Sub
End Class
