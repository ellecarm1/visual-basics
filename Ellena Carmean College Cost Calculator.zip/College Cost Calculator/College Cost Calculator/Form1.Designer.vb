﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.NumOfCreditHoursTextBox = New System.Windows.Forms.TextBox()
        Me.CostOfBooksTextBox = New System.Windows.Forms.TextBox()
        Me.RoomAndBoardTextBox = New System.Windows.Forms.TextBox()
        Me.MiscellaneousExpensesTextBox = New System.Windows.Forms.TextBox()
        Me.Cost_Of_Tuition_Label = New System.Windows.Forms.Label()
        Me.Total_Cost_For_Student_LabelBox = New System.Windows.Forms.Label()
        Me.Num_Of_Students_Processed_LabelBox = New System.Windows.Forms.Label()
        Me.Total_Cost_For_All_Students_LabelBox = New System.Windows.Forms.Label()
        Me.Average_Cost_Per_Student_LabelBox = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.CalcButton = New System.Windows.Forms.Button()
        Me.ClearButton = New System.Windows.Forms.Button()
        Me.ExitButton = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'NumOfCreditHoursTextBox
        '
        Me.NumOfCreditHoursTextBox.Location = New System.Drawing.Point(249, 87)
        Me.NumOfCreditHoursTextBox.Name = "NumOfCreditHoursTextBox"
        Me.NumOfCreditHoursTextBox.Size = New System.Drawing.Size(100, 23)
        Me.NumOfCreditHoursTextBox.TabIndex = 0
        '
        'CostOfBooksTextBox
        '
        Me.CostOfBooksTextBox.Location = New System.Drawing.Point(249, 128)
        Me.CostOfBooksTextBox.Name = "CostOfBooksTextBox"
        Me.CostOfBooksTextBox.Size = New System.Drawing.Size(100, 23)
        Me.CostOfBooksTextBox.TabIndex = 1
        '
        'RoomAndBoardTextBox
        '
        Me.RoomAndBoardTextBox.Location = New System.Drawing.Point(249, 167)
        Me.RoomAndBoardTextBox.Name = "RoomAndBoardTextBox"
        Me.RoomAndBoardTextBox.Size = New System.Drawing.Size(100, 23)
        Me.RoomAndBoardTextBox.TabIndex = 2
        '
        'MiscellaneousExpensesTextBox
        '
        Me.MiscellaneousExpensesTextBox.Location = New System.Drawing.Point(249, 205)
        Me.MiscellaneousExpensesTextBox.Name = "MiscellaneousExpensesTextBox"
        Me.MiscellaneousExpensesTextBox.Size = New System.Drawing.Size(100, 23)
        Me.MiscellaneousExpensesTextBox.TabIndex = 3
        '
        'Cost_Of_Tuition_Label
        '
        Me.Cost_Of_Tuition_Label.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Cost_Of_Tuition_Label.Location = New System.Drawing.Point(249, 250)
        Me.Cost_Of_Tuition_Label.Name = "Cost_Of_Tuition_Label"
        Me.Cost_Of_Tuition_Label.Size = New System.Drawing.Size(100, 23)
        Me.Cost_Of_Tuition_Label.TabIndex = 4
        '
        'Total_Cost_For_Student_LabelBox
        '
        Me.Total_Cost_For_Student_LabelBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Total_Cost_For_Student_LabelBox.Location = New System.Drawing.Point(249, 297)
        Me.Total_Cost_For_Student_LabelBox.Name = "Total_Cost_For_Student_LabelBox"
        Me.Total_Cost_For_Student_LabelBox.Size = New System.Drawing.Size(100, 23)
        Me.Total_Cost_For_Student_LabelBox.TabIndex = 5
        '
        'Num_Of_Students_Processed_LabelBox
        '
        Me.Num_Of_Students_Processed_LabelBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Num_Of_Students_Processed_LabelBox.Location = New System.Drawing.Point(565, 169)
        Me.Num_Of_Students_Processed_LabelBox.Name = "Num_Of_Students_Processed_LabelBox"
        Me.Num_Of_Students_Processed_LabelBox.Size = New System.Drawing.Size(100, 23)
        Me.Num_Of_Students_Processed_LabelBox.TabIndex = 6
        '
        'Total_Cost_For_All_Students_LabelBox
        '
        Me.Total_Cost_For_All_Students_LabelBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Total_Cost_For_All_Students_LabelBox.Location = New System.Drawing.Point(565, 210)
        Me.Total_Cost_For_All_Students_LabelBox.Name = "Total_Cost_For_All_Students_LabelBox"
        Me.Total_Cost_For_All_Students_LabelBox.Size = New System.Drawing.Size(100, 23)
        Me.Total_Cost_For_All_Students_LabelBox.TabIndex = 7
        '
        'Average_Cost_Per_Student_LabelBox
        '
        Me.Average_Cost_Per_Student_LabelBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Average_Cost_Per_Student_LabelBox.Location = New System.Drawing.Point(565, 250)
        Me.Average_Cost_Per_Student_LabelBox.Name = "Average_Cost_Per_Student_LabelBox"
        Me.Average_Cost_Per_Student_LabelBox.Size = New System.Drawing.Size(100, 23)
        Me.Average_Cost_Per_Student_LabelBox.TabIndex = 8
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(143, 95)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(98, 15)
        Me.Label6.TabIndex = 9
        Me.Label6.Text = "# of Credit Hours"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(159, 136)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(82, 15)
        Me.Label7.TabIndex = 10
        Me.Label7.Text = "Cost Of Books"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(145, 175)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(96, 15)
        Me.Label8.TabIndex = 11
        Me.Label8.Text = "Room and Board"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(108, 213)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(133, 15)
        Me.Label9.TabIndex = 12
        Me.Label9.Text = "Miscellaneous Expenses"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(73, 258)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(168, 15)
        Me.Label10.TabIndex = 13
        Me.Label10.Text = "Cost of Tuition ($125 per hour)"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(116, 305)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(124, 15)
        Me.Label11.TabIndex = 14
        Me.Label11.Text = "Total Cost for Student:"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(367, 218)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(192, 15)
        Me.Label12.TabIndex = 15
        Me.Label12.Text = "Total Cost for ALL Students Entered"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(367, 141)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(110, 15)
        Me.Label13.TabIndex = 16
        Me.Label13.Text = "Totals for All Entries"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(389, 177)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(170, 15)
        Me.Label14.TabIndex = 17
        Me.Label14.Text = "Number of Students Processed"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(418, 258)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(141, 15)
        Me.Label15.TabIndex = 18
        Me.Label15.Text = "Average Cost Per Student"
        '
        'CalcButton
        '
        Me.CalcButton.Location = New System.Drawing.Point(249, 364)
        Me.CalcButton.Name = "CalcButton"
        Me.CalcButton.Size = New System.Drawing.Size(75, 23)
        Me.CalcButton.TabIndex = 19
        Me.CalcButton.Text = "Calculate"
        Me.CalcButton.UseVisualStyleBackColor = True
        '
        'ClearButton
        '
        Me.ClearButton.Location = New System.Drawing.Point(343, 364)
        Me.ClearButton.Name = "ClearButton"
        Me.ClearButton.Size = New System.Drawing.Size(75, 23)
        Me.ClearButton.TabIndex = 20
        Me.ClearButton.Text = "Clear"
        Me.ClearButton.UseVisualStyleBackColor = True
        '
        'ExitButton
        '
        Me.ExitButton.Location = New System.Drawing.Point(437, 364)
        Me.ExitButton.Name = "ExitButton"
        Me.ExitButton.Size = New System.Drawing.Size(75, 23)
        Me.ExitButton.TabIndex = 21
        Me.ExitButton.Text = "Exit"
        Me.ExitButton.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.ExitButton)
        Me.Controls.Add(Me.ClearButton)
        Me.Controls.Add(Me.CalcButton)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Average_Cost_Per_Student_LabelBox)
        Me.Controls.Add(Me.Total_Cost_For_All_Students_LabelBox)
        Me.Controls.Add(Me.Num_Of_Students_Processed_LabelBox)
        Me.Controls.Add(Me.Total_Cost_For_Student_LabelBox)
        Me.Controls.Add(Me.Cost_Of_Tuition_Label)
        Me.Controls.Add(Me.MiscellaneousExpensesTextBox)
        Me.Controls.Add(Me.RoomAndBoardTextBox)
        Me.Controls.Add(Me.CostOfBooksTextBox)
        Me.Controls.Add(Me.NumOfCreditHoursTextBox)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents NumOfCreditHoursTextBox As TextBox
    Friend WithEvents CostOfBooksTextBox As TextBox
    Friend WithEvents RoomAndBoardTextBox As TextBox
    Friend WithEvents MiscellaneousExpensesTextBox As TextBox
    Friend WithEvents Cost_Of_Tuition_Label As Label
    Friend WithEvents Total_Cost_For_Student_LabelBox As Label
    Friend WithEvents Num_Of_Students_Processed_LabelBox As Label
    Friend WithEvents Total_Cost_For_All_Students_LabelBox As Label
    Friend WithEvents Average_Cost_Per_Student_LabelBox As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents CalcButton As Button
    Friend WithEvents ClearButton As Button
    Friend WithEvents ExitButton As Button
End Class
