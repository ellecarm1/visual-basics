﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TotalsButton = New System.Windows.Forms.Button()
        Me.TotalLabel = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.PwdTextbox = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.NameTextbox = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.DeliveryCheckBox = New System.Windows.Forms.CheckBox()
        Me.LoginButton = New System.Windows.Forms.Button()
        Me.ExitButton = New System.Windows.Forms.Button()
        Me.ClearButton = New System.Windows.Forms.Button()
        Me.CalcButton = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.LiqueurCheckBox = New System.Windows.Forms.CheckBox()
        Me.WhippedCreamCheckBox = New System.Windows.Forms.CheckBox()
        Me.SyrupCheckBox = New System.Windows.Forms.CheckBox()
        Me.DblCheckBox = New System.Windows.Forms.CheckBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.XLRadioButton = New System.Windows.Forms.RadioButton()
        Me.LargeRadioButton = New System.Windows.Forms.RadioButton()
        Me.MediumRadioButton = New System.Windows.Forms.RadioButton()
        Me.SmallRadioButton = New System.Windows.Forms.RadioButton()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Monotype Corsiva", 14.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(172, 29)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(290, 22)
        Me.Label6.TabIndex = 32
        Me.Label6.Text = "Serving GROB employees since 1978"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Comic Sans MS", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(354, 197)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(211, 16)
        Me.Label5.TabIndex = 31
        Me.Label5.Text = "Brought to your office for only $1.00!!!"
        '
        'TotalsButton
        '
        Me.TotalsButton.BackColor = System.Drawing.Color.Peru
        Me.TotalsButton.Enabled = False
        Me.TotalsButton.Location = New System.Drawing.Point(317, 332)
        Me.TotalsButton.Name = "TotalsButton"
        Me.TotalsButton.Size = New System.Drawing.Size(75, 23)
        Me.TotalsButton.TabIndex = 30
        Me.TotalsButton.Text = "Totals"
        Me.TotalsButton.UseVisualStyleBackColor = False
        '
        'TotalLabel
        '
        Me.TotalLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TotalLabel.Font = New System.Drawing.Font("Century Gothic", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TotalLabel.Location = New System.Drawing.Point(354, 235)
        Me.TotalLabel.Name = "TotalLabel"
        Me.TotalLabel.Size = New System.Drawing.Size(231, 78)
        Me.TotalLabel.TabIndex = 29
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(354, 218)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(88, 13)
        Me.Label3.TabIndex = 28
        Me.Label3.Text = "Your Order Total:"
        '
        'PwdTextbox
        '
        Me.PwdTextbox.Location = New System.Drawing.Point(357, 68)
        Me.PwdTextbox.Name = "PwdTextbox"
        Me.PwdTextbox.Size = New System.Drawing.Size(100, 20)
        Me.PwdTextbox.TabIndex = 20
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(298, 75)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(53, 13)
        Me.Label2.TabIndex = 19
        Me.Label2.Text = "Password"
        '
        'NameTextbox
        '
        Me.NameTextbox.Location = New System.Drawing.Point(137, 68)
        Me.NameTextbox.Name = "NameTextbox"
        Me.NameTextbox.Size = New System.Drawing.Size(125, 20)
        Me.NameTextbox.TabIndex = 18
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(92, 68)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(38, 13)
        Me.Label1.TabIndex = 17
        Me.Label1.Text = "Name:"
        '
        'DeliveryCheckBox
        '
        Me.DeliveryCheckBox.AutoSize = True
        Me.DeliveryCheckBox.Font = New System.Drawing.Font("Comic Sans MS", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DeliveryCheckBox.Location = New System.Drawing.Point(354, 177)
        Me.DeliveryCheckBox.Name = "DeliveryCheckBox"
        Me.DeliveryCheckBox.Size = New System.Drawing.Size(90, 20)
        Me.DeliveryCheckBox.TabIndex = 24
        Me.DeliveryCheckBox.Text = "For Delivery"
        Me.DeliveryCheckBox.UseVisualStyleBackColor = True
        '
        'LoginButton
        '
        Me.LoginButton.BackColor = System.Drawing.Color.Peru
        Me.LoginButton.Location = New System.Drawing.Point(243, 105)
        Me.LoginButton.Name = "LoginButton"
        Me.LoginButton.Size = New System.Drawing.Size(75, 23)
        Me.LoginButton.TabIndex = 21
        Me.LoginButton.Text = "Login"
        Me.LoginButton.UseVisualStyleBackColor = False
        '
        'ExitButton
        '
        Me.ExitButton.BackColor = System.Drawing.Color.Peru
        Me.ExitButton.Location = New System.Drawing.Point(427, 332)
        Me.ExitButton.Name = "ExitButton"
        Me.ExitButton.Size = New System.Drawing.Size(75, 23)
        Me.ExitButton.TabIndex = 27
        Me.ExitButton.Text = "Exit"
        Me.ExitButton.UseVisualStyleBackColor = False
        '
        'ClearButton
        '
        Me.ClearButton.BackColor = System.Drawing.Color.Peru
        Me.ClearButton.Enabled = False
        Me.ClearButton.Location = New System.Drawing.Point(207, 332)
        Me.ClearButton.Name = "ClearButton"
        Me.ClearButton.Size = New System.Drawing.Size(75, 23)
        Me.ClearButton.TabIndex = 26
        Me.ClearButton.Text = "Clear"
        Me.ClearButton.UseVisualStyleBackColor = False
        '
        'CalcButton
        '
        Me.CalcButton.BackColor = System.Drawing.Color.Peru
        Me.CalcButton.Enabled = False
        Me.CalcButton.Location = New System.Drawing.Point(97, 332)
        Me.CalcButton.Name = "CalcButton"
        Me.CalcButton.Size = New System.Drawing.Size(75, 23)
        Me.CalcButton.TabIndex = 25
        Me.CalcButton.Text = "Calc Order"
        Me.CalcButton.UseVisualStyleBackColor = False
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.LiqueurCheckBox)
        Me.GroupBox2.Controls.Add(Me.WhippedCreamCheckBox)
        Me.GroupBox2.Controls.Add(Me.SyrupCheckBox)
        Me.GroupBox2.Controls.Add(Me.DblCheckBox)
        Me.GroupBox2.Location = New System.Drawing.Point(186, 182)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(131, 130)
        Me.GroupBox2.TabIndex = 23
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Choose Your Add-Ins"
        '
        'LiqueurCheckBox
        '
        Me.LiqueurCheckBox.AutoSize = True
        Me.LiqueurCheckBox.Location = New System.Drawing.Point(7, 92)
        Me.LiqueurCheckBox.Name = "LiqueurCheckBox"
        Me.LiqueurCheckBox.Size = New System.Drawing.Size(61, 17)
        Me.LiqueurCheckBox.TabIndex = 3
        Me.LiqueurCheckBox.Text = "Liqueur"
        Me.LiqueurCheckBox.UseVisualStyleBackColor = True
        '
        'WhippedCreamCheckBox
        '
        Me.WhippedCreamCheckBox.AutoSize = True
        Me.WhippedCreamCheckBox.Location = New System.Drawing.Point(7, 68)
        Me.WhippedCreamCheckBox.Name = "WhippedCreamCheckBox"
        Me.WhippedCreamCheckBox.Size = New System.Drawing.Size(102, 17)
        Me.WhippedCreamCheckBox.TabIndex = 2
        Me.WhippedCreamCheckBox.Text = "Whipped Cream"
        Me.WhippedCreamCheckBox.UseVisualStyleBackColor = True
        '
        'SyrupCheckBox
        '
        Me.SyrupCheckBox.AutoSize = True
        Me.SyrupCheckBox.Location = New System.Drawing.Point(7, 44)
        Me.SyrupCheckBox.Name = "SyrupCheckBox"
        Me.SyrupCheckBox.Size = New System.Drawing.Size(97, 17)
        Me.SyrupCheckBox.TabIndex = 1
        Me.SyrupCheckBox.Text = "Flavored Syrup"
        Me.SyrupCheckBox.UseVisualStyleBackColor = True
        '
        'DblCheckBox
        '
        Me.DblCheckBox.AutoSize = True
        Me.DblCheckBox.Location = New System.Drawing.Point(7, 20)
        Me.DblCheckBox.Name = "DblCheckBox"
        Me.DblCheckBox.Size = New System.Drawing.Size(85, 17)
        Me.DblCheckBox.TabIndex = 0
        Me.DblCheckBox.Text = "Double Shot"
        Me.DblCheckBox.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.XLRadioButton)
        Me.GroupBox1.Controls.Add(Me.LargeRadioButton)
        Me.GroupBox1.Controls.Add(Me.MediumRadioButton)
        Me.GroupBox1.Controls.Add(Me.SmallRadioButton)
        Me.GroupBox1.Location = New System.Drawing.Point(48, 182)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(115, 130)
        Me.GroupBox1.TabIndex = 22
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Choose size:"
        '
        'XLRadioButton
        '
        Me.XLRadioButton.AutoSize = True
        Me.XLRadioButton.Location = New System.Drawing.Point(7, 92)
        Me.XLRadioButton.Name = "XLRadioButton"
        Me.XLRadioButton.Size = New System.Drawing.Size(79, 17)
        Me.XLRadioButton.TabIndex = 3
        Me.XLRadioButton.Text = "Extra Large"
        Me.XLRadioButton.UseVisualStyleBackColor = True
        '
        'LargeRadioButton
        '
        Me.LargeRadioButton.AutoSize = True
        Me.LargeRadioButton.Location = New System.Drawing.Point(7, 68)
        Me.LargeRadioButton.Name = "LargeRadioButton"
        Me.LargeRadioButton.Size = New System.Drawing.Size(52, 17)
        Me.LargeRadioButton.TabIndex = 2
        Me.LargeRadioButton.Text = "Large"
        Me.LargeRadioButton.UseVisualStyleBackColor = True
        '
        'MediumRadioButton
        '
        Me.MediumRadioButton.AutoSize = True
        Me.MediumRadioButton.Location = New System.Drawing.Point(7, 44)
        Me.MediumRadioButton.Name = "MediumRadioButton"
        Me.MediumRadioButton.Size = New System.Drawing.Size(62, 17)
        Me.MediumRadioButton.TabIndex = 1
        Me.MediumRadioButton.Text = "Medium"
        Me.MediumRadioButton.UseVisualStyleBackColor = True
        '
        'SmallRadioButton
        '
        Me.SmallRadioButton.AutoSize = True
        Me.SmallRadioButton.Checked = True
        Me.SmallRadioButton.Location = New System.Drawing.Point(7, 20)
        Me.SmallRadioButton.Name = "SmallRadioButton"
        Me.SmallRadioButton.Size = New System.Drawing.Size(50, 17)
        Me.SmallRadioButton.TabIndex = 0
        Me.SmallRadioButton.TabStop = True
        Me.SmallRadioButton.Text = "Small"
        Me.SmallRadioButton.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.BurlyWood
        Me.ClientSize = New System.Drawing.Size(622, 426)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.TotalsButton)
        Me.Controls.Add(Me.TotalLabel)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.PwdTextbox)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.NameTextbox)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.DeliveryCheckBox)
        Me.Controls.Add(Me.LoginButton)
        Me.Controls.Add(Me.ExitButton)
        Me.Controls.Add(Me.ClearButton)
        Me.Controls.Add(Me.CalcButton)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "Java Jeans Coffee"
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents TotalsButton As Button
    Friend WithEvents TotalLabel As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents PwdTextbox As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents NameTextbox As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents DeliveryCheckBox As CheckBox
    Friend WithEvents LoginButton As Button
    Friend WithEvents ExitButton As Button
    Friend WithEvents ClearButton As Button
    Friend WithEvents CalcButton As Button
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents LiqueurCheckBox As CheckBox
    Friend WithEvents WhippedCreamCheckBox As CheckBox
    Friend WithEvents SyrupCheckBox As CheckBox
    Friend WithEvents DblCheckBox As CheckBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents XLRadioButton As RadioButton
    Friend WithEvents LargeRadioButton As RadioButton
    Friend WithEvents MediumRadioButton As RadioButton
    Friend WithEvents SmallRadioButton As RadioButton
End Class
