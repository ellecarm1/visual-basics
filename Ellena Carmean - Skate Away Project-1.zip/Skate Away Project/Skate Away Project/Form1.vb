﻿Public Class Form1
    'Ellena Carmean'
    'Visual Basics'
    'Skate Away Project'
    'September 21, 2021'
    Private Sub ExitButton_Click(sender As Object, e As EventArgs) Handles ExitButton.Click
        Close()
        'When the user clicks this button, it will close the program'
    End Sub

    Private Sub CalcButton_Click(sender As Object, e As EventArgs) Handles CalcButton.Click

        TotalBoardsLabel.Text = NumOfBlueSkateboardsTextBox.Text & NumOfYellowSkateboardsTextBox.Text

        'first 3 variables we get from the user'
        Dim NumberOfBlueSkateboards, NumberOfYellowSkateboards As Integer
        Dim TotalBoards As Integer

        'needs decimal for their cost'
        Dim Subtotal As Decimal
        Dim SalesTax As Decimal
        Dim TotalPrice As Decimal

        'now we need to convert their 2 intries'
        NumberOfBlueSkateboards = CInt(NumOfBlueSkateboardsTextBox.Text)
        NumberOfYellowSkateboards = CInt(NumOfYellowSkateboardsTextBox.Text)

        'math'
        TotalBoards = NumberOfBlueSkateboards + NumberOfYellowSkateboards
        Subtotal = TotalBoards * 100
        SalesTax = Subtotal * 0.07
        TotalPrice = Subtotal + SalesTax

        'output'
        TotalPriceLabel.Text = TotalPrice.ToString("c")
    End Sub

    Private Sub ClearButton_Click(sender As Object, e As EventArgs) Handles ClearButton.Click
        NameTextBox.Text = ""
        AddressTextBox.Text = ""
        CityTextBox.Text = ""
        StateTextBox.Text = ""
        LabelTextBox.Text = ""
        'This event will clear the form'
    End Sub
End Class
