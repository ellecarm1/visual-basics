﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.CalcButton = New System.Windows.Forms.Button()
        Me.ClearButton = New System.Windows.Forms.Button()
        Me.ExitButton = New System.Windows.Forms.Button()
        Me.NameTextBox = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.LabelTextBox = New System.Windows.Forms.TextBox()
        Me.StateTextBox = New System.Windows.Forms.TextBox()
        Me.CityTextBox = New System.Windows.Forms.TextBox()
        Me.AddressTextBox = New System.Windows.Forms.TextBox()
        Me.IDLabel = New System.Windows.Forms.Label()
        Me.BlueSkateBoardsLabel = New System.Windows.Forms.Label()
        Me.YellowSkateboardsLabel = New System.Windows.Forms.Label()
        Me.ZipLabel = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.CityLabel = New System.Windows.Forms.Label()
        Me.AddressLabel = New System.Windows.Forms.Label()
        Me.PriceLabelTextBox = New System.Windows.Forms.Label()
        Me.BoardsLabel = New System.Windows.Forms.Label()
        Me.NumOfBlueSkateboardsTextBox = New System.Windows.Forms.TextBox()
        Me.NumOfYellowSkateboardsTextBox = New System.Windows.Forms.TextBox()
        Me.TotalPriceLabel = New System.Windows.Forms.Label()
        Me.TotalBoardsLabel = New System.Windows.Forms.Label()
        Me.SkateAwayLabel = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'CalcButton
        '
        Me.CalcButton.Location = New System.Drawing.Point(506, 103)
        Me.CalcButton.Name = "CalcButton"
        Me.CalcButton.Size = New System.Drawing.Size(131, 23)
        Me.CalcButton.TabIndex = 0
        Me.CalcButton.Text = "Calculate Order"
        Me.CalcButton.UseVisualStyleBackColor = True
        '
        'ClearButton
        '
        Me.ClearButton.Location = New System.Drawing.Point(506, 133)
        Me.ClearButton.Name = "ClearButton"
        Me.ClearButton.Size = New System.Drawing.Size(131, 23)
        Me.ClearButton.TabIndex = 1
        Me.ClearButton.Text = "Clear Screen"
        Me.ClearButton.UseVisualStyleBackColor = True
        '
        'ExitButton
        '
        Me.ExitButton.Location = New System.Drawing.Point(506, 163)
        Me.ExitButton.Name = "ExitButton"
        Me.ExitButton.Size = New System.Drawing.Size(131, 23)
        Me.ExitButton.TabIndex = 2
        Me.ExitButton.Text = "Exit"
        Me.ExitButton.UseVisualStyleBackColor = True
        '
        'NameTextBox
        '
        Me.NameTextBox.Location = New System.Drawing.Point(228, 105)
        Me.NameTextBox.Name = "NameTextBox"
        Me.NameTextBox.Size = New System.Drawing.Size(170, 23)
        Me.NameTextBox.TabIndex = 3
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(263, 163)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(100, 23)
        Me.TextBox2.TabIndex = 4
        '
        'LabelTextBox
        '
        Me.LabelTextBox.Location = New System.Drawing.Point(334, 193)
        Me.LabelTextBox.Name = "LabelTextBox"
        Me.LabelTextBox.Size = New System.Drawing.Size(64, 23)
        Me.LabelTextBox.TabIndex = 6
        '
        'StateTextBox
        '
        Me.StateTextBox.Location = New System.Drawing.Point(228, 193)
        Me.StateTextBox.Name = "StateTextBox"
        Me.StateTextBox.Size = New System.Drawing.Size(40, 23)
        Me.StateTextBox.TabIndex = 7
        '
        'CityTextBox
        '
        Me.CityTextBox.Location = New System.Drawing.Point(228, 163)
        Me.CityTextBox.Name = "CityTextBox"
        Me.CityTextBox.Size = New System.Drawing.Size(170, 23)
        Me.CityTextBox.TabIndex = 8
        '
        'AddressTextBox
        '
        Me.AddressTextBox.Location = New System.Drawing.Point(228, 134)
        Me.AddressTextBox.Name = "AddressTextBox"
        Me.AddressTextBox.Size = New System.Drawing.Size(170, 23)
        Me.AddressTextBox.TabIndex = 9
        '
        'IDLabel
        '
        Me.IDLabel.AutoSize = True
        Me.IDLabel.Location = New System.Drawing.Point(142, 113)
        Me.IDLabel.Name = "IDLabel"
        Me.IDLabel.Size = New System.Drawing.Size(42, 15)
        Me.IDLabel.TabIndex = 10
        Me.IDLabel.Text = "Name:"
        '
        'BlueSkateBoardsLabel
        '
        Me.BlueSkateBoardsLabel.AutoSize = True
        Me.BlueSkateBoardsLabel.Location = New System.Drawing.Point(142, 274)
        Me.BlueSkateBoardsLabel.Name = "BlueSkateBoardsLabel"
        Me.BlueSkateBoardsLabel.Size = New System.Drawing.Size(146, 15)
        Me.BlueSkateBoardsLabel.TabIndex = 13
        Me.BlueSkateBoardsLabel.Text = "Blue Skateboards Ordered:"
        '
        'YellowSkateboardsLabel
        '
        Me.YellowSkateboardsLabel.AutoSize = True
        Me.YellowSkateboardsLabel.Location = New System.Drawing.Point(142, 300)
        Me.YellowSkateboardsLabel.Name = "YellowSkateboardsLabel"
        Me.YellowSkateboardsLabel.Size = New System.Drawing.Size(157, 15)
        Me.YellowSkateboardsLabel.TabIndex = 14
        Me.YellowSkateboardsLabel.Text = "Yellow Skateboards Ordered:"
        '
        'ZipLabel
        '
        Me.ZipLabel.AutoSize = True
        Me.ZipLabel.Location = New System.Drawing.Point(287, 201)
        Me.ZipLabel.Name = "ZipLabel"
        Me.ZipLabel.Size = New System.Drawing.Size(38, 15)
        Me.ZipLabel.TabIndex = 15
        Me.ZipLabel.Text = "Label:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(142, 201)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(36, 15)
        Me.Label7.TabIndex = 16
        Me.Label7.Text = "State:"
        '
        'CityLabel
        '
        Me.CityLabel.AutoSize = True
        Me.CityLabel.Location = New System.Drawing.Point(142, 171)
        Me.CityLabel.Name = "CityLabel"
        Me.CityLabel.Size = New System.Drawing.Size(31, 15)
        Me.CityLabel.TabIndex = 17
        Me.CityLabel.Text = "City:"
        '
        'AddressLabel
        '
        Me.AddressLabel.AutoSize = True
        Me.AddressLabel.Location = New System.Drawing.Point(142, 142)
        Me.AddressLabel.Name = "AddressLabel"
        Me.AddressLabel.Size = New System.Drawing.Size(52, 15)
        Me.AddressLabel.TabIndex = 18
        Me.AddressLabel.Text = "Address:"
        '
        'PriceLabelTextBox
        '
        Me.PriceLabelTextBox.AutoSize = True
        Me.PriceLabelTextBox.Location = New System.Drawing.Point(467, 300)
        Me.PriceLabelTextBox.Name = "PriceLabelTextBox"
        Me.PriceLabelTextBox.Size = New System.Drawing.Size(64, 15)
        Me.PriceLabelTextBox.TabIndex = 11
        Me.PriceLabelTextBox.Text = "Total Price:"
        '
        'BoardsLabel
        '
        Me.BoardsLabel.AutoSize = True
        Me.BoardsLabel.Location = New System.Drawing.Point(467, 274)
        Me.BoardsLabel.Name = "BoardsLabel"
        Me.BoardsLabel.Size = New System.Drawing.Size(102, 15)
        Me.BoardsLabel.TabIndex = 12
        Me.BoardsLabel.Text = "Total Skateboards:"
        '
        'NumOfBlueSkateboardsTextBox
        '
        Me.NumOfBlueSkateboardsTextBox.Location = New System.Drawing.Point(348, 266)
        Me.NumOfBlueSkateboardsTextBox.Name = "NumOfBlueSkateboardsTextBox"
        Me.NumOfBlueSkateboardsTextBox.Size = New System.Drawing.Size(50, 23)
        Me.NumOfBlueSkateboardsTextBox.TabIndex = 20
        '
        'NumOfYellowSkateboardsTextBox
        '
        Me.NumOfYellowSkateboardsTextBox.Location = New System.Drawing.Point(348, 292)
        Me.NumOfYellowSkateboardsTextBox.Name = "NumOfYellowSkateboardsTextBox"
        Me.NumOfYellowSkateboardsTextBox.Size = New System.Drawing.Size(50, 23)
        Me.NumOfYellowSkateboardsTextBox.TabIndex = 21
        '
        'TotalPriceLabel
        '
        Me.TotalPriceLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TotalPriceLabel.Location = New System.Drawing.Point(575, 300)
        Me.TotalPriceLabel.Name = "TotalPriceLabel"
        Me.TotalPriceLabel.Size = New System.Drawing.Size(100, 23)
        Me.TotalPriceLabel.TabIndex = 22
        '
        'TotalBoardsLabel
        '
        Me.TotalBoardsLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TotalBoardsLabel.Location = New System.Drawing.Point(575, 266)
        Me.TotalBoardsLabel.Name = "TotalBoardsLabel"
        Me.TotalBoardsLabel.Size = New System.Drawing.Size(100, 23)
        Me.TotalBoardsLabel.TabIndex = 23
        '
        'SkateAwayLabel
        '
        Me.SkateAwayLabel.Font = New System.Drawing.Font("Fresh Lychee", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.SkateAwayLabel.Location = New System.Drawing.Point(142, 39)
        Me.SkateAwayLabel.Name = "SkateAwayLabel"
        Me.SkateAwayLabel.Size = New System.Drawing.Size(446, 53)
        Me.SkateAwayLabel.TabIndex = 24
        Me.SkateAwayLabel.Text = "Skate-Away Sales Order Form"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.SkateAwayLabel)
        Me.Controls.Add(Me.TotalBoardsLabel)
        Me.Controls.Add(Me.TotalPriceLabel)
        Me.Controls.Add(Me.NumOfYellowSkateboardsTextBox)
        Me.Controls.Add(Me.NumOfBlueSkateboardsTextBox)
        Me.Controls.Add(Me.AddressLabel)
        Me.Controls.Add(Me.CityLabel)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.ZipLabel)
        Me.Controls.Add(Me.YellowSkateboardsLabel)
        Me.Controls.Add(Me.BlueSkateBoardsLabel)
        Me.Controls.Add(Me.BoardsLabel)
        Me.Controls.Add(Me.PriceLabelTextBox)
        Me.Controls.Add(Me.IDLabel)
        Me.Controls.Add(Me.AddressTextBox)
        Me.Controls.Add(Me.CityTextBox)
        Me.Controls.Add(Me.StateTextBox)
        Me.Controls.Add(Me.LabelTextBox)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.NameTextBox)
        Me.Controls.Add(Me.ExitButton)
        Me.Controls.Add(Me.ClearButton)
        Me.Controls.Add(Me.CalcButton)
        Me.Name = "Form1"
        Me.Text = "Skate Away Project"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents CalcButton As Button
    Friend WithEvents ClearButton As Button
    Friend WithEvents ExitButton As Button
    Friend WithEvents NameTextBox As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents LabelTextBox As TextBox
    Friend WithEvents StateTextBox As TextBox
    Friend WithEvents CityTextBox As TextBox
    Friend WithEvents AddressTextBox As TextBox
    Friend WithEvents IDLabel As Label
    Friend WithEvents BlueSkateBoardsLabel As Label
    Friend WithEvents YellowSkateboardsLabel As Label
    Friend WithEvents ZipLabel As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents CityLabel As Label
    Friend WithEvents AddressLabel As Label
    Friend WithEvents PriceLabelTextBox As Label
    Friend WithEvents BoardsLabel As Label
    Friend WithEvents NumOfBlueSkateboardsTextBox As TextBox
    Friend WithEvents NumOfYellowSkateboardsTextBox As TextBox
    Friend WithEvents TotalPriceTextBox As Label
    Friend WithEvents TotalBoardsTextBox As Label
    Friend WithEvents SkateAwayLabel As Label
    Friend WithEvents TotalPrice As Label
    Friend WithEvents TotalPriceLabel As Label
    Friend WithEvents TotalBoardsLabel As Label
End Class
