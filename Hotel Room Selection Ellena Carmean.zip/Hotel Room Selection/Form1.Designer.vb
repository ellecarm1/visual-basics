﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FindingNemoForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.CloseButton = New System.Windows.Forms.Button()
        Me.LoginButton = New System.Windows.Forms.Button()
        Me.LocationButton = New System.Windows.Forms.Button()
        Me.OffersBox1 = New System.Windows.Forms.Label()
        Me.HelloMessageBox = New System.Windows.Forms.Label()
        Me.EnterNameTextBox = New System.Windows.Forms.TextBox()
        Me.EnterNameHereBox = New System.Windows.Forms.Label()
        Me.HotelBox1 = New System.Windows.Forms.PictureBox()
        Me.HotelBox2 = New System.Windows.Forms.PictureBox()
        Me.HotelBox3 = New System.Windows.Forms.PictureBox()
        Me.ClickImageLabel = New System.Windows.Forms.Label()
        Me.Room1Label = New System.Windows.Forms.Label()
        Me.Room2Label = New System.Windows.Forms.Label()
        Me.Room3Label = New System.Windows.Forms.Label()
        CType(Me.HotelBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HotelBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HotelBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'CloseButton
        '
        Me.CloseButton.Location = New System.Drawing.Point(361, 415)
        Me.CloseButton.Name = "CloseButton"
        Me.CloseButton.Size = New System.Drawing.Size(75, 23)
        Me.CloseButton.TabIndex = 0
        Me.CloseButton.Text = "Close"
        Me.CloseButton.UseVisualStyleBackColor = True
        '
        'LoginButton
        '
        Me.LoginButton.Location = New System.Drawing.Point(390, 50)
        Me.LoginButton.Name = "LoginButton"
        Me.LoginButton.Size = New System.Drawing.Size(75, 23)
        Me.LoginButton.TabIndex = 1
        Me.LoginButton.Text = "Login"
        Me.LoginButton.UseVisualStyleBackColor = True
        '
        'LocationButton
        '
        Me.LocationButton.Location = New System.Drawing.Point(361, 375)
        Me.LocationButton.Name = "LocationButton"
        Me.LocationButton.Size = New System.Drawing.Size(75, 23)
        Me.LocationButton.TabIndex = 2
        Me.LocationButton.Text = "Location"
        Me.LocationButton.UseVisualStyleBackColor = True
        '
        'OffersBox1
        '
        Me.OffersBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.OffersBox1.Location = New System.Drawing.Point(284, 292)
        Me.OffersBox1.Name = "OffersBox1"
        Me.OffersBox1.Size = New System.Drawing.Size(235, 70)
        Me.OffersBox1.TabIndex = 3
        '
        'HelloMessageBox
        '
        Me.HelloMessageBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.HelloMessageBox.Location = New System.Drawing.Point(497, 41)
        Me.HelloMessageBox.Name = "HelloMessageBox"
        Me.HelloMessageBox.Size = New System.Drawing.Size(206, 53)
        Me.HelloMessageBox.TabIndex = 4
        '
        'EnterNameTextBox
        '
        Me.EnterNameTextBox.Location = New System.Drawing.Point(253, 50)
        Me.EnterNameTextBox.Name = "EnterNameTextBox"
        Me.EnterNameTextBox.Size = New System.Drawing.Size(100, 23)
        Me.EnterNameTextBox.TabIndex = 5
        '
        'EnterNameHereBox
        '
        Me.EnterNameHereBox.AutoSize = True
        Me.EnterNameHereBox.Font = New System.Drawing.Font("SimSun", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.EnterNameHereBox.Location = New System.Drawing.Point(110, 55)
        Me.EnterNameHereBox.Name = "EnterNameHereBox"
        Me.EnterNameHereBox.Size = New System.Drawing.Size(117, 12)
        Me.EnterNameHereBox.TabIndex = 6
        Me.EnterNameHereBox.Text = "Enter your name:"
        '
        'HotelBox1
        '
        Me.HotelBox1.Image = Global.Hotel_Room_Selection.My.Resources.Resources.StandardRoom
        Me.HotelBox1.Location = New System.Drawing.Point(173, 144)
        Me.HotelBox1.Name = "HotelBox1"
        Me.HotelBox1.Size = New System.Drawing.Size(104, 134)
        Me.HotelBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.HotelBox1.TabIndex = 7
        Me.HotelBox1.TabStop = False
        '
        'HotelBox2
        '
        Me.HotelBox2.Image = Global.Hotel_Room_Selection.My.Resources.Resources.DeluxeRoom
        Me.HotelBox2.Location = New System.Drawing.Point(349, 144)
        Me.HotelBox2.Name = "HotelBox2"
        Me.HotelBox2.Size = New System.Drawing.Size(104, 134)
        Me.HotelBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.HotelBox2.TabIndex = 8
        Me.HotelBox2.TabStop = False
        '
        'HotelBox3
        '
        Me.HotelBox3.Image = Global.Hotel_Room_Selection.My.Resources.Resources.SuiteRoom
        Me.HotelBox3.Location = New System.Drawing.Point(525, 144)
        Me.HotelBox3.Name = "HotelBox3"
        Me.HotelBox3.Size = New System.Drawing.Size(104, 134)
        Me.HotelBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.HotelBox3.TabIndex = 9
        Me.HotelBox3.TabStop = False
        '
        'ClickImageLabel
        '
        Me.ClickImageLabel.AutoSize = True
        Me.ClickImageLabel.Font = New System.Drawing.Font("Monotype Corsiva", 14.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.ClickImageLabel.Location = New System.Drawing.Point(164, 94)
        Me.ClickImageLabel.Name = "ClickImageLabel"
        Me.ClickImageLabel.Size = New System.Drawing.Size(480, 22)
        Me.ClickImageLabel.TabIndex = 10
        Me.ClickImageLabel.Text = "Click an image below to view info about your room selection"
        '
        'Room1Label
        '
        Me.Room1Label.AutoSize = True
        Me.Room1Label.Font = New System.Drawing.Font("SimSun", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.Room1Label.Location = New System.Drawing.Point(173, 126)
        Me.Room1Label.Name = "Room1Label"
        Me.Room1Label.Size = New System.Drawing.Size(61, 12)
        Me.Room1Label.TabIndex = 11
        Me.Room1Label.Text = "Standard"
        '
        'Room2Label
        '
        Me.Room2Label.AutoSize = True
        Me.Room2Label.Font = New System.Drawing.Font("SimSun", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.Room2Label.Location = New System.Drawing.Point(349, 126)
        Me.Room2Label.Name = "Room2Label"
        Me.Room2Label.Size = New System.Drawing.Size(47, 12)
        Me.Room2Label.TabIndex = 12
        Me.Room2Label.Text = "Deluxe"
        '
        'Room3Label
        '
        Me.Room3Label.AutoSize = True
        Me.Room3Label.Font = New System.Drawing.Font("SimSun", 9.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.Room3Label.Location = New System.Drawing.Point(525, 126)
        Me.Room3Label.Name = "Room3Label"
        Me.Room3Label.Size = New System.Drawing.Size(40, 12)
        Me.Room3Label.TabIndex = 13
        Me.Room3Label.Text = "Suite"
        '
        'FindingNemoForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Room3Label)
        Me.Controls.Add(Me.Room2Label)
        Me.Controls.Add(Me.Room1Label)
        Me.Controls.Add(Me.ClickImageLabel)
        Me.Controls.Add(Me.HotelBox3)
        Me.Controls.Add(Me.HotelBox2)
        Me.Controls.Add(Me.HotelBox1)
        Me.Controls.Add(Me.EnterNameHereBox)
        Me.Controls.Add(Me.EnterNameTextBox)
        Me.Controls.Add(Me.HelloMessageBox)
        Me.Controls.Add(Me.OffersBox1)
        Me.Controls.Add(Me.LocationButton)
        Me.Controls.Add(Me.LoginButton)
        Me.Controls.Add(Me.CloseButton)
        Me.Name = "FindingNemoForm"
        Me.Text = "Finding Nemo"
        CType(Me.HotelBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HotelBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HotelBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents CloseButton As Button
    Friend WithEvents LoginButton As Button
    Friend WithEvents LocationButton As Button
    Friend WithEvents OffersBox1 As Label
    Friend WithEvents HelloMessageBox As Label
    Friend WithEvents EnterNameTextBox As TextBox
    Friend WithEvents EnterNameHereBox As Label
    Friend WithEvents HotelBox1 As PictureBox
    Friend WithEvents HotelBox2 As PictureBox
    Friend WithEvents HotelBox3 As PictureBox
    Friend WithEvents ClickImageLabel As Label
    Friend WithEvents Room1Label As Label
    Friend WithEvents Room2Label As Label
    Friend WithEvents Room3Label As Label
End Class
