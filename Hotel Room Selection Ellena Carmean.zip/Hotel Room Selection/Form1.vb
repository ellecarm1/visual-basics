﻿Public Class FindingNemoForm
    'Mrs. Hueve'
    'VB Programming'
    'Ellena Carmean'
    'September 13th, 2021'
    Private Sub CloseButton_Click(sender As Object, e As EventArgs) Handles CloseButton.Click
        Close()
        'when this button is clicked the program will close'
    End Sub

    Private Sub LoginButton_Click(sender As Object, e As EventArgs) Handles LoginButton.Click
        HelloMessageBox.Text = "hello" & EnterNameTextBox.Text & ControlChars.NewLine & "Enjoy your stay with us"
        'when the user puts in their name and clicks login, the label will greet them, and display their name followed by a message'
    End Sub

    Private Sub LocationButton_Click(sender As Object, e As EventArgs) Handles LocationButton.Click
        MessageBox.Show("42 Wallaby Way")
        'when this button is clicked the location of the hotel will pop up in a message box'
    End Sub

    Private Sub HotelBox1_Click(sender As Object, e As EventArgs) Handles HotelBox1.Click
        OffersBox1.Text = "This room has wifi" & ControlChars.NewLine & "Free spa visit included"
        'when this picturebox is clicked the label box will display offers for the standard room'
    End Sub

    Private Sub HotelBox2_Click(sender As Object, e As EventArgs) Handles HotelBox2.Click
        OffersBox1.Text = "This room has a huge tv" & ControlChars.NewLine & "Free spa visit included"
        'when this picturebox is clicked the label box will display offers for the deluxe room'
    End Sub

    Private Sub HotelBox3_Click(sender As Object, e As EventArgs) Handles HotelBox3.Click
        OffersBox1.Text = "This room has a jacuzzi" & ControlChars.NewLine & "Free spa visit included"
        'when this picturebox is clicked the label box will display offers for the suite'
    End Sub
End Class
