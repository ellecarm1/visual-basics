﻿'smoothie project
'ellena carmean
'11/23/21

Option Strict On
Imports System.IO
Public Class SmoothieForm
    Private Const protein = 0.5D
    Private Const vitamins = 0.75D
    Private Const flaxseed = 0.5D
    Private Const green_tea = 1D
    Private Const spinach = 0.25D
    Friend quantity As Integer
    Friend order_cost As Decimal
    Friend totalsmoothies As Integer
    Friend totalreceipts As Decimal




    Private Sub CalculateOrderToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CalculateOrderToolStripMenuItem.Click
        Dim smoothieprice As Decimal
        Dim add_in_price As Decimal
        Try
            If SmoothieComboBox.SelectedIndex <> -1 Then
                If SmoothieComboBox.SelectedIndex >= 0 Then
                    smoothieprice = 5D
                    'conversions
                    quantity = CInt(QuantityTextBox.Text)
                    If quantity > 0 Then
                        'accumulating values in check boxes
                        If ProteinCheckBox.Checked = True Then
                            add_in_price += protein
                        End If
                        If VitaminsCheckBox.Checked = True Then
                            add_in_price += vitamins
                        End If
                        If FlaxseedCheckBox.Checked = True Then
                            add_in_price += flaxseed
                        End If
                        If GreenTeaCheckBox.Checked = True Then
                            add_in_price += green_tea
                        End If
                        If SpinachCheckBox.Checked = True Then
                            add_in_price += spinach
                        End If
                    Else
                        MessageBox.Show("value cannot be less than 1")
                    End If

                Else
                    MessageBox.Show("please select a smoothie flavor")
                End If
            Else
                MessageBox.Show("please select a smoothie flavor")
            End If
            If order_cost < 0 Then
                order_cost = 0
            End If

            'calculations

            order_cost = (smoothieprice + add_in_price) * quantity
            totalsmoothies += quantity
            totalreceipts += order_cost
            'display
            'CostLabel.Text = order_cost.ToString("c2")

        Catch ex As Exception
            MessageBox.Show("must complete form to calculate total")
        End Try
    End Sub


    Private Sub SmoothieForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ''add smoothie flavors
        'SmoothieComboBox.Items.Add("Strawberry Banana")
        'SmoothieComboBox.Items.Add("Peach")
        'SmoothieComboBox.Items.Add("Mango")
        'SmoothieComboBox.Items.Add("Cherry")
        Try
            'read the locations file and place each
            'line into the list box
            Dim LocationReader As New StreamReader("smoothieflavors.txt")
            Dim eachLocation As String
            While LocationReader.Peek <> -1
                eachLocation = LocationReader.ReadLine
                SmoothieComboBox.Items.Add(eachLocation)
            End While

            'close the file!!!
            LocationReader.Close()



        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub AddSmoothFlavorToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddSmoothFlavorToolStripMenuItem.Click
        'add some items to the names combo box
        'write some data to a file
        Dim fileWriter As New StreamWriter("smoothieflavors.txt")
        fileWriter.WriteLine("strawberry banana")
        fileWriter.WriteLine("peach")
        fileWriter.WriteLine("mango")
        fileWriter.WriteLine("cherry")
        fileWriter.WriteLine(SmoothieComboBox.Text)

        'must remember to close the file
        fileWriter.Close()
        Dim namefound As Boolean = False
        Dim index As Integer = 0

        'searching that list
        While namefound = False And index < SmoothieComboBox.Items.Count
            If SmoothieComboBox.Text = SmoothieComboBox.Items(index).ToString Then
                namefound = True
            Else
                index += 1
            End If
        End While

        'check the value of namefound
        If namefound = True Then
            MessageBox.Show("No duplicates please")
        Else
            SmoothieComboBox.Items.Add(SmoothieComboBox.Text)
        End If
    End Sub

    Private Sub RemoveSmoothieFlavorToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RemoveSmoothieFlavorToolStripMenuItem.Click
        'remove the selected flavor from the flowers list box
        Dim selection As Integer
        selection = SmoothieComboBox.SelectedIndex
        If selection <> -1 Then
            SmoothieComboBox.Items.RemoveAt(selection)
        Else
            MessageBox.Show("select a flavor to remove")
        End If

    End Sub

    Private Sub ClearToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ClearToolStripMenuItem.Click
        'clear the entire classes list box
        Dim answer As DialogResult
        answer = MessageBox.Show("this will reset the form, would you like to clear totals?", "clear totals", MessageBoxButtons.YesNo)
        If answer = DialogResult.Yes Then
            SmoothieComboBox.SelectedIndex = 0
            ProteinCheckBox.Checked = False
            VitaminsCheckBox.Checked = False
            FlaxseedCheckBox.Checked = False
            GreenTeaCheckBox.Checked = False
            SpinachCheckBox.Checked = False
            QuantityTextBox.Clear()
            'CostLabel.Text = ""
        Else

        End If
    End Sub

    Private Sub Smoothie_Document_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles Smoothie_Document.PrintPage
        'here is where we create our report

        Dim smoothiefont As New Font("times new roman", 20)
        e.Graphics.DrawString("Limas best smoothie shop", smoothiefont, Brushes.Black, 150, 20)
        'loop through all the flowers in the list box and print each on a new line
        Dim index As Integer
        Dim Y As Integer = 80
        For index = 0 To SmoothieComboBox.Items.Count - 1
            e.Graphics.DrawString(SmoothieComboBox.Items(index).ToString, smoothiefont, Brushes.Green, 25, Y)
            'add to our y coordinate
            Y += 20
        Next

        'report footer
        Y += 20
        e.Graphics.DrawString("thank you for choosing our smoothies", smoothiefont, Brushes.Purple, 150, Y)
    End Sub

    Private Sub PrintSmoothieFlavorsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PrintSmoothieFlavorsToolStripMenuItem.Click
        Smoothie_Print_Dialog.Document = Smoothie_Document
        Smoothie_Print_Dialog.ShowDialog()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        'this event closes the program
        Close()
    End Sub

    Private Sub ShowSummaryInfoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ShowSummaryInfoToolStripMenuItem.Click
        'display summary for with the summary data
        SummaryForm.ShowDialog()

    End Sub

    Private Sub SmoothieForm_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        'this event executes when the form is trying to close
        'ask the user if they wish to save their data
        'with yes/no/cancel options
        Dim answer As DialogResult
        answer = MessageBox.Show("Save changes?", "Save", MessageBoxButtons.YesNoCancel)
        If answer = DialogResult.Yes Then
            'save our list box data
            Dim ListBoxWriter As New StreamWriter("smoothieflavors.txt")
            Dim Index As Integer = 0
            For Index = 0 To SmoothieComboBox.Items.Count - 1
                ListBoxWriter.WriteLine(SmoothieComboBox.Items(Index))

            Next
            'close the file!!!!!
            ListBoxWriter.Close()

            'save our 2 totals to another file
            Dim totalwriter As New StreamWriter("smoothietotals.txt")
            totalwriter.WriteLine(totalsmoothies)
            totalwriter.WriteLine(totalreceipts)
            totalwriter.Close()

            'now were going to read our totals file
            Dim totalsreader As New StreamReader("smoothietotals.txt")
            totalsmoothies = CInt(totalsreader.ReadLine)
            totalreceipts = CDec(totalsreader.ReadLine)


        End If
        If answer = DialogResult.Cancel Then
            e.Cancel = True

        End If
    End Sub


End Class
