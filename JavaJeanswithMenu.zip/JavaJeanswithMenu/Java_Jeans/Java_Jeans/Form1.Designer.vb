﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TotalLabel = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.PwdTextbox = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.NameTextbox = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.DeliveryCheckBox = New System.Windows.Forms.CheckBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.LiqueurCheckBox = New System.Windows.Forms.CheckBox()
        Me.WhippedCreamCheckBox = New System.Windows.Forms.CheckBox()
        Me.SyrupCheckBox = New System.Windows.Forms.CheckBox()
        Me.DblCheckBox = New System.Windows.Forms.CheckBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.JavaJean_Login_Menu_Button = New System.Windows.Forms.ToolStripMenuItem()
        Me.JavaJean_Calculate_Menu_Button = New System.Windows.Forms.ToolStripMenuItem()
        Me.JavaJean_ShowTotal_MenuButton = New System.Windows.Forms.ToolStripMenuItem()
        Me.JavaJean_Exit_MenuButton = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.JavaJean_Clear_MenuButton = New System.Windows.Forms.ToolStripMenuItem()
        Me.JavaJean_Font_MenuButton = New System.Windows.Forms.ToolStripMenuItem()
        Me.JavaJean_Color_MenuButton = New System.Windows.Forms.ToolStripMenuItem()
        Me.Coffee_Font_Button = New System.Windows.Forms.FontDialog()
        Me.Coffee_Color_Button = New System.Windows.Forms.ColorDialog()
        Me.JavaJeans_CoffeeSize_ListBox = New System.Windows.Forms.ListBox()
        Me.GroupBox2.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(172, 29)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(359, 24)
        Me.Label6.TabIndex = 32
        Me.Label6.Text = "Serving GROB employees since 1978"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Comic Sans MS", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(354, 197)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(211, 16)
        Me.Label5.TabIndex = 31
        Me.Label5.Text = "Brought to your office for only $1.00!!!"
        '
        'TotalLabel
        '
        Me.TotalLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TotalLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TotalLabel.Location = New System.Drawing.Point(354, 235)
        Me.TotalLabel.Name = "TotalLabel"
        Me.TotalLabel.Size = New System.Drawing.Size(231, 78)
        Me.TotalLabel.TabIndex = 29
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(354, 218)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(88, 13)
        Me.Label3.TabIndex = 28
        Me.Label3.Text = "Your Order Total:"
        '
        'PwdTextbox
        '
        Me.PwdTextbox.Location = New System.Drawing.Point(357, 68)
        Me.PwdTextbox.Name = "PwdTextbox"
        Me.PwdTextbox.Size = New System.Drawing.Size(100, 20)
        Me.PwdTextbox.TabIndex = 20
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(298, 75)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(53, 13)
        Me.Label2.TabIndex = 19
        Me.Label2.Text = "Password"
        '
        'NameTextbox
        '
        Me.NameTextbox.Location = New System.Drawing.Point(137, 68)
        Me.NameTextbox.Name = "NameTextbox"
        Me.NameTextbox.Size = New System.Drawing.Size(125, 20)
        Me.NameTextbox.TabIndex = 18
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(92, 68)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(38, 13)
        Me.Label1.TabIndex = 17
        Me.Label1.Text = "Name:"
        '
        'DeliveryCheckBox
        '
        Me.DeliveryCheckBox.AutoSize = True
        Me.DeliveryCheckBox.Font = New System.Drawing.Font("Comic Sans MS", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DeliveryCheckBox.Location = New System.Drawing.Point(354, 177)
        Me.DeliveryCheckBox.Name = "DeliveryCheckBox"
        Me.DeliveryCheckBox.Size = New System.Drawing.Size(90, 20)
        Me.DeliveryCheckBox.TabIndex = 24
        Me.DeliveryCheckBox.Text = "For Delivery"
        Me.DeliveryCheckBox.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.LiqueurCheckBox)
        Me.GroupBox2.Controls.Add(Me.WhippedCreamCheckBox)
        Me.GroupBox2.Controls.Add(Me.SyrupCheckBox)
        Me.GroupBox2.Controls.Add(Me.DblCheckBox)
        Me.GroupBox2.Location = New System.Drawing.Point(186, 182)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(131, 130)
        Me.GroupBox2.TabIndex = 23
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Choose Your Add-Ins"
        '
        'LiqueurCheckBox
        '
        Me.LiqueurCheckBox.AutoSize = True
        Me.LiqueurCheckBox.Location = New System.Drawing.Point(7, 92)
        Me.LiqueurCheckBox.Name = "LiqueurCheckBox"
        Me.LiqueurCheckBox.Size = New System.Drawing.Size(61, 17)
        Me.LiqueurCheckBox.TabIndex = 3
        Me.LiqueurCheckBox.Text = "Liqueur"
        Me.LiqueurCheckBox.UseVisualStyleBackColor = True
        '
        'WhippedCreamCheckBox
        '
        Me.WhippedCreamCheckBox.AutoSize = True
        Me.WhippedCreamCheckBox.Location = New System.Drawing.Point(7, 68)
        Me.WhippedCreamCheckBox.Name = "WhippedCreamCheckBox"
        Me.WhippedCreamCheckBox.Size = New System.Drawing.Size(102, 17)
        Me.WhippedCreamCheckBox.TabIndex = 2
        Me.WhippedCreamCheckBox.Text = "Whipped Cream"
        Me.WhippedCreamCheckBox.UseVisualStyleBackColor = True
        '
        'SyrupCheckBox
        '
        Me.SyrupCheckBox.AutoSize = True
        Me.SyrupCheckBox.Location = New System.Drawing.Point(7, 44)
        Me.SyrupCheckBox.Name = "SyrupCheckBox"
        Me.SyrupCheckBox.Size = New System.Drawing.Size(97, 17)
        Me.SyrupCheckBox.TabIndex = 1
        Me.SyrupCheckBox.Text = "Flavored Syrup"
        Me.SyrupCheckBox.UseVisualStyleBackColor = True
        '
        'DblCheckBox
        '
        Me.DblCheckBox.AutoSize = True
        Me.DblCheckBox.Location = New System.Drawing.Point(7, 20)
        Me.DblCheckBox.Name = "DblCheckBox"
        Me.DblCheckBox.Size = New System.Drawing.Size(85, 17)
        Me.DblCheckBox.TabIndex = 0
        Me.DblCheckBox.Text = "Double Shot"
        Me.DblCheckBox.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.EditToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(622, 24)
        Me.MenuStrip1.TabIndex = 33
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.JavaJean_Login_Menu_Button, Me.JavaJean_Calculate_Menu_Button, Me.JavaJean_ShowTotal_MenuButton, Me.JavaJean_Exit_MenuButton})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'JavaJean_Login_Menu_Button
        '
        Me.JavaJean_Login_Menu_Button.Name = "JavaJean_Login_Menu_Button"
        Me.JavaJean_Login_Menu_Button.Size = New System.Drawing.Size(136, 22)
        Me.JavaJean_Login_Menu_Button.Text = "Log in"
        '
        'JavaJean_Calculate_Menu_Button
        '
        Me.JavaJean_Calculate_Menu_Button.Enabled = False
        Me.JavaJean_Calculate_Menu_Button.Name = "JavaJean_Calculate_Menu_Button"
        Me.JavaJean_Calculate_Menu_Button.Size = New System.Drawing.Size(136, 22)
        Me.JavaJean_Calculate_Menu_Button.Text = "Calculate"
        '
        'JavaJean_ShowTotal_MenuButton
        '
        Me.JavaJean_ShowTotal_MenuButton.Enabled = False
        Me.JavaJean_ShowTotal_MenuButton.Name = "JavaJean_ShowTotal_MenuButton"
        Me.JavaJean_ShowTotal_MenuButton.Size = New System.Drawing.Size(136, 22)
        Me.JavaJean_ShowTotal_MenuButton.Text = "Show Totals"
        '
        'JavaJean_Exit_MenuButton
        '
        Me.JavaJean_Exit_MenuButton.Name = "JavaJean_Exit_MenuButton"
        Me.JavaJean_Exit_MenuButton.Size = New System.Drawing.Size(136, 22)
        Me.JavaJean_Exit_MenuButton.Text = "Exit"
        '
        'EditToolStripMenuItem
        '
        Me.EditToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.JavaJean_Clear_MenuButton, Me.JavaJean_Font_MenuButton, Me.JavaJean_Color_MenuButton})
        Me.EditToolStripMenuItem.Name = "EditToolStripMenuItem"
        Me.EditToolStripMenuItem.Size = New System.Drawing.Size(39, 20)
        Me.EditToolStripMenuItem.Text = "Edit"
        '
        'JavaJean_Clear_MenuButton
        '
        Me.JavaJean_Clear_MenuButton.Enabled = False
        Me.JavaJean_Clear_MenuButton.Name = "JavaJean_Clear_MenuButton"
        Me.JavaJean_Clear_MenuButton.Size = New System.Drawing.Size(103, 22)
        Me.JavaJean_Clear_MenuButton.Text = "Clear"
        '
        'JavaJean_Font_MenuButton
        '
        Me.JavaJean_Font_MenuButton.Name = "JavaJean_Font_MenuButton"
        Me.JavaJean_Font_MenuButton.Size = New System.Drawing.Size(103, 22)
        Me.JavaJean_Font_MenuButton.Text = "Font"
        '
        'JavaJean_Color_MenuButton
        '
        Me.JavaJean_Color_MenuButton.Name = "JavaJean_Color_MenuButton"
        Me.JavaJean_Color_MenuButton.Size = New System.Drawing.Size(103, 22)
        Me.JavaJean_Color_MenuButton.Text = "Color"
        '
        'JavaJeans_CoffeeSize_ListBox
        '
        Me.JavaJeans_CoffeeSize_ListBox.FormattingEnabled = True
        Me.JavaJeans_CoffeeSize_ListBox.Location = New System.Drawing.Point(34, 188)
        Me.JavaJeans_CoffeeSize_ListBox.Name = "JavaJeans_CoffeeSize_ListBox"
        Me.JavaJeans_CoffeeSize_ListBox.Size = New System.Drawing.Size(120, 121)
        Me.JavaJeans_CoffeeSize_ListBox.TabIndex = 34
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.BurlyWood
        Me.ClientSize = New System.Drawing.Size(622, 426)
        Me.Controls.Add(Me.JavaJeans_CoffeeSize_ListBox)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.TotalLabel)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.PwdTextbox)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.NameTextbox)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.DeliveryCheckBox)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "Java Jeans Coffee"
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents TotalLabel As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents PwdTextbox As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents NameTextbox As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents DeliveryCheckBox As CheckBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents LiqueurCheckBox As CheckBox
    Friend WithEvents WhippedCreamCheckBox As CheckBox
    Friend WithEvents SyrupCheckBox As CheckBox
    Friend WithEvents DblCheckBox As CheckBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents JavaJean_Login_Menu_Button As ToolStripMenuItem
    Friend WithEvents JavaJean_Calculate_Menu_Button As ToolStripMenuItem
    Friend WithEvents JavaJean_ShowTotal_MenuButton As ToolStripMenuItem
    Friend WithEvents JavaJean_Exit_MenuButton As ToolStripMenuItem
    Friend WithEvents EditToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents JavaJean_Clear_MenuButton As ToolStripMenuItem
    Friend WithEvents JavaJean_Font_MenuButton As ToolStripMenuItem
    Friend WithEvents JavaJean_Color_MenuButton As ToolStripMenuItem
    Friend WithEvents Coffee_Font_Button As FontDialog
    Friend WithEvents Coffee_Color_Button As ColorDialog
    Friend WithEvents JavaJeans_CoffeeSize_ListBox As ListBox
End Class
