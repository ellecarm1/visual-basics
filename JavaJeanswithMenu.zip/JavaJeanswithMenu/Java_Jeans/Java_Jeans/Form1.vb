﻿'ellena carmean
'visual basics
'java jeans with menu 
'10/30/21

Option Strict On

Public Class Form1
    Private Const small_coffee_price = 1D
    Private Const medium_coffee_price = 2.5D
    Private Const large_coffee_price = 3D
    Private Const extra_large_price = 3.5D
    Private Const double_shot = 1.5D
    Private Const syrup = 0.75D
    Private Const whipped_cream = 0.5D
    Private Const liqeur = 2D
    Private Const delivery_fee = 1D
    Dim total_coffees As Integer
    Dim total_deliveries_made As Integer

    Private Sub LogInToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles JavaJean_Login_Menu_Button.Click
        'this drop down is the same as the log in button

        Dim customer_name_ As String = NameTextbox.Text
        Dim customer_password As String = PwdTextbox.Text
        If NameTextbox.Text <> "" Then
            'we are going to make sure login and email have values; this is an example of a nested if 
            If PwdTextbox.Text <> "" Then
                If customer_name_.ToUpper.Trim = "JAVAJEANS" And customer_password = "CoffeeBeans" Then
                    JavaJean_Calculate_Menu_Button.Enabled = True
                    JavaJean_Clear_MenuButton.Enabled = True
                    JavaJean_ShowTotal_MenuButton.Enabled = True
                    JavaJean_Login_Menu_Button.Enabled = False
                    NameTextbox.Enabled = False
                    PwdTextbox.Enabled = False
                    MessageBox.Show("you are authenticated")
                Else
                    MessageBox.Show("you are not permitted")
                End If
            Else
                MessageBox.Show("Email is required")
            End If
        Else
            MessageBox.Show("Name is required")
        End If
    End Sub

    Private Sub CalculateToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles JavaJean_Calculate_Menu_Button.Click
        'this drop down is the same as the calculate button
        Dim add_in_price As Decimal
        Dim coffee_price As Decimal
        Dim total_order_price As Decimal
        Try

            ''when only one radio button can be chosen
            'If SmallRadioButton.Checked = True Then
            '    coffee_price = small_coffee_price
            'ElseIf MediumRadioButton.Checked = True Then
            '    coffee_price = medium_coffee_price
            'ElseIf LargeRadioButton.Checked = True Then
            '    coffee_price = large_coffee_price
            'ElseIf XLRadioButton.Checked = True Then
            '    coffee_price = extra_large_price
            'Else
            '    MessageBox.Show("please select coffee size")
            'End If

            'determine which list box item is selected
            If JavaJeans_CoffeeSize_ListBox.SelectedIndex = 0 Then
                coffee_price = small_coffee_price
            ElseIf JavaJeans_CoffeeSize_ListBox.SelectedIndex = 1 Then
                coffee_price = medium_coffee_price
            ElseIf JavaJeans_CoffeeSize_ListBox.SelectedIndex = 2 Then
                coffee_price = large_coffee_price
            ElseIf JavaJeans_CoffeeSize_ListBox.SelectedIndex = 3 Then
                coffee_price = extra_large_price
            Else
                MessageBox.Show("please select coffee size")
            End If

            'accumulating values in check boxes
            If DblCheckBox.Checked = True Then
                add_in_price += double_shot
            End If
            If SyrupCheckBox.Checked = True Then
                add_in_price += syrup
            End If
            If WhippedCreamCheckBox.Checked = True Then
                add_in_price += whipped_cream
            End If
            If LiqueurCheckBox.Checked = True Then
                add_in_price += liqeur
            End If

            If DeliveryCheckBox.Checked = True Then
                total_deliveries_made += 1
                total_order_price = coffee_price + add_in_price + delivery_fee
            Else
                total_order_price = coffee_price + add_in_price
            End If

            TotalLabel.Text = "Your total order cost is: " & total_order_price.ToString("c2") & ControlChars.NewLine & "total add ins: " & add_in_price.ToString("c2") & ControlChars.NewLine & "please come again soon :)"

            total_coffees += 1

        Catch ex As Exception

        End Try
    End Sub

    Private Sub ShowTotalsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles JavaJean_ShowTotal_MenuButton.Click
        'this will display a message box that will display totals
        MessageBox.Show("total coffees: " & total_coffees & ControlChars.NewLine & "total deliveries: " & total_deliveries_made)
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles JavaJean_Exit_MenuButton.Click
        Close()
    End Sub

    Private Sub ClearToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles JavaJean_Clear_MenuButton.Click
        'this button will ask if the user would like to clear everything or just the form 
        Dim answer As DialogResult
        answer = MessageBox.Show("this will reset the form, would you like to clear totals?", "clear totals", MessageBoxButtons.YesNo)
        If answer = DialogResult.Yes Then

            JavaJeans_CoffeeSize_ListBox.SelectedIndex = 0
            DblCheckBox.Checked = False
            SyrupCheckBox.Checked = False
            WhippedCreamCheckBox.Checked = False
            LiqueurCheckBox.Checked = False
            DeliveryCheckBox.Checked = False
            TotalLabel.Text = ""
            total_coffees = 0
            total_deliveries_made = 0
            'you set a variable to 0 for accumulative values'
        Else

            JavaJeans_CoffeeSize_ListBox.SelectedIndex = 0
            DblCheckBox.Checked = False
            SyrupCheckBox.Checked = False
            WhippedCreamCheckBox.Checked = False
            LiqueurCheckBox.Checked = False
            DeliveryCheckBox.Checked = False
            TotalLabel.Text = ""
        End If
    End Sub

    Private Sub FontToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles JavaJean_Font_MenuButton.Click
        'show the font dialog box, allow the user to make their selection
        'then apply their selection to our window
        Coffee_Font_Button.ShowDialog()
        'no apply the font dialog box to property to our window
        'me refers to this window
        Me.Font = Coffee_Font_Button.Font
    End Sub

    Private Sub ColorToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles JavaJean_Color_MenuButton.Click
        'bring up the color dialog box
        Coffee_Color_Button.ShowDialog()
        'apply their slection to our window
        Me.BackColor = Coffee_Color_Button.Color
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'this event executes before the user sees the window 
        'here we will add ourr items to the list box
        JavaJeans_CoffeeSize_ListBox.Items.Add("Small")
        JavaJeans_CoffeeSize_ListBox.Items.Add("Medium")
        JavaJeans_CoffeeSize_ListBox.Items.Add("Large")
        JavaJeans_CoffeeSize_ListBox.Items.Add("Extra Large")
    End Sub
End Class
'nest ifs 
