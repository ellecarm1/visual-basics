﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ResultOneLabelBox = New System.Windows.Forms.Label()
        Me.ResultTwoLabelBox = New System.Windows.Forms.Label()
        Me.ResultThreeLabelBox = New System.Windows.Forms.Label()
        Me.TestOneTextBox = New System.Windows.Forms.TextBox()
        Me.TestTwoTextBox = New System.Windows.Forms.TextBox()
        Me.TestThreeTextBox = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.TotalResultsLabel = New System.Windows.Forms.Label()
        Me.CalcButton = New System.Windows.Forms.Button()
        Me.ClearButton = New System.Windows.Forms.Button()
        Me.ExitButton = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'ResultOneLabelBox
        '
        Me.ResultOneLabelBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ResultOneLabelBox.Location = New System.Drawing.Point(327, 140)
        Me.ResultOneLabelBox.Name = "ResultOneLabelBox"
        Me.ResultOneLabelBox.Size = New System.Drawing.Size(67, 23)
        Me.ResultOneLabelBox.TabIndex = 0
        '
        'ResultTwoLabelBox
        '
        Me.ResultTwoLabelBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ResultTwoLabelBox.Location = New System.Drawing.Point(327, 187)
        Me.ResultTwoLabelBox.Name = "ResultTwoLabelBox"
        Me.ResultTwoLabelBox.Size = New System.Drawing.Size(67, 23)
        Me.ResultTwoLabelBox.TabIndex = 1
        '
        'ResultThreeLabelBox
        '
        Me.ResultThreeLabelBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ResultThreeLabelBox.Location = New System.Drawing.Point(327, 231)
        Me.ResultThreeLabelBox.Name = "ResultThreeLabelBox"
        Me.ResultThreeLabelBox.Size = New System.Drawing.Size(67, 23)
        Me.ResultThreeLabelBox.TabIndex = 2
        '
        'TestOneTextBox
        '
        Me.TestOneTextBox.Location = New System.Drawing.Point(79, 140)
        Me.TestOneTextBox.Name = "TestOneTextBox"
        Me.TestOneTextBox.Size = New System.Drawing.Size(100, 23)
        Me.TestOneTextBox.TabIndex = 3
        '
        'TestTwoTextBox
        '
        Me.TestTwoTextBox.Location = New System.Drawing.Point(79, 187)
        Me.TestTwoTextBox.Name = "TestTwoTextBox"
        Me.TestTwoTextBox.Size = New System.Drawing.Size(100, 23)
        Me.TestTwoTextBox.TabIndex = 4
        '
        'TestThreeTextBox
        '
        Me.TestThreeTextBox.Location = New System.Drawing.Point(79, 231)
        Me.TestThreeTextBox.Name = "TestThreeTextBox"
        Me.TestThreeTextBox.Size = New System.Drawing.Size(100, 23)
        Me.TestThreeTextBox.TabIndex = 5
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(28, 143)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(39, 15)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Test 1:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(28, 190)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(39, 15)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "Test 2:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(28, 234)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(39, 15)
        Me.Label6.TabIndex = 8
        Me.Label6.Text = "Test 3:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(79, 113)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(159, 15)
        Me.Label7.TabIndex = 9
        Me.Label7.Text = "Your Score    /Possible Points"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(185, 143)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(24, 15)
        Me.Label8.TabIndex = 10
        Me.Label8.Text = "/72"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(185, 190)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(24, 15)
        Me.Label9.TabIndex = 11
        Me.Label9.Text = "/90"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(185, 234)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(24, 15)
        Me.Label10.TabIndex = 12
        Me.Label10.Text = "/57"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(327, 113)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(61, 15)
        Me.Label11.TabIndex = 13
        Me.Label11.Text = "Test Grade"
        '
        'TotalResultsLabel
        '
        Me.TotalResultsLabel.BackColor = System.Drawing.Color.White
        Me.TotalResultsLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TotalResultsLabel.Location = New System.Drawing.Point(55, 300)
        Me.TotalResultsLabel.Name = "TotalResultsLabel"
        Me.TotalResultsLabel.Size = New System.Drawing.Size(315, 23)
        Me.TotalResultsLabel.TabIndex = 14
        '
        'CalcButton
        '
        Me.CalcButton.Location = New System.Drawing.Point(68, 346)
        Me.CalcButton.Name = "CalcButton"
        Me.CalcButton.Size = New System.Drawing.Size(75, 23)
        Me.CalcButton.TabIndex = 15
        Me.CalcButton.Text = "Calculate"
        Me.CalcButton.UseVisualStyleBackColor = True
        '
        'ClearButton
        '
        Me.ClearButton.Location = New System.Drawing.Point(175, 346)
        Me.ClearButton.Name = "ClearButton"
        Me.ClearButton.Size = New System.Drawing.Size(75, 23)
        Me.ClearButton.TabIndex = 16
        Me.ClearButton.Text = "Clear"
        Me.ClearButton.UseVisualStyleBackColor = True
        '
        'ExitButton
        '
        Me.ExitButton.Location = New System.Drawing.Point(276, 346)
        Me.ExitButton.Name = "ExitButton"
        Me.ExitButton.Size = New System.Drawing.Size(75, 23)
        Me.ExitButton.TabIndex = 17
        Me.ExitButton.Text = "Exit"
        Me.ExitButton.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(454, 450)
        Me.Controls.Add(Me.ExitButton)
        Me.Controls.Add(Me.ClearButton)
        Me.Controls.Add(Me.CalcButton)
        Me.Controls.Add(Me.TotalResultsLabel)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.TestThreeTextBox)
        Me.Controls.Add(Me.TestTwoTextBox)
        Me.Controls.Add(Me.TestOneTextBox)
        Me.Controls.Add(Me.ResultThreeLabelBox)
        Me.Controls.Add(Me.ResultTwoLabelBox)
        Me.Controls.Add(Me.ResultOneLabelBox)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ResultOneLabelBox As Label
    Friend WithEvents ResultTwoLabelBox As Label
    Friend WithEvents ResultThreeLabelBox As Label
    Friend WithEvents TestOneTextBox As TextBox
    Friend WithEvents TestTwoTextBox As TextBox
    Friend WithEvents TestThreeTextBox As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents TotalResultsLabel As Label
    Friend WithEvents CalcButton As Button
    Friend WithEvents ClearButton As Button
    Friend WithEvents ExitButton As Button
End Class
