﻿'displays summary data for all car rentals
Public Class SummaryForm

    Private Sub CloseButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CloseButton.Click
        Close()

    End Sub

    Private Sub SummaryForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GrandTotalRentalsLabel.Text = CostCalculatorForm.total_rentals.ToString
        GrandTotalMilesLabel.Text = CostCalculatorForm.total_mileage.ToString
        GrandTotalReceiptsLabel.Text = CostCalculatorForm.totalreceipts.ToString("C2")
    End Sub
End Class