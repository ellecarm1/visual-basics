﻿
Option Strict On
Imports System.IO


Public Class CostCalculatorForm
    Const COMPACT_RATE As Decimal = 45D
    Const MIDSIZE_RATE As Decimal = 50D
    Const PREMIUN_RATE As Decimal = 55D
    Const MINIVAN_RATE As Decimal = 60D
    Const SUV_RATE As Decimal = 65D
    Const MILEAGE_RATE As Decimal = 0.05D
    'these are our accumulating values
    Friend total_rentals As Integer
    Friend total_mileage As Decimal
    Friend totalreceipts As Decimal

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'do NOT comment these out or write to a file
        VehicleListBox.Items.Add("Compact - $45/day")
        VehicleListBox.Items.Add("Mid-Size - $50/day")
        VehicleListBox.Items.Add("Premium - $55/day")
        VehicleListBox.Items.Add("Minivan - $60/day")
        VehicleListBox.Items.Add("SUV - $65/day")

        Try
            'add code here to read file info and place data into correct variables
            'only ONE file is to be read - the file with the 3 totals)

            'save our 2 totals to another file
            Dim totalsreader As New StreamReader("carrentaltotals.txt")
            Dim lineofdata As String
            'convert it and add to totalsmoothies sold
            lineofdata = totalsreader.ReadLine
            total_rentals = CInt(lineofdata)
            lineofdata = totalsreader.ReadLine
            total_mileage = CDec(lineofdata)
            lineofdata = totalsreader.ReadLine
            totalreceipts = CDec(lineofdata)
            'close the file
            totalsreader.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error")
        End Try
    End Sub

    Private Sub ClearToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearToolStripMenuItem.Click
        VehicleListBox.SelectedIndex = -1
        TotalMilesLabel.Text = ""
        CustomerChargeLabel.Text = ""
        DaysTextBox.Clear()
        BeginningTextBox.Clear()
        EndingTextBox.Clear()

    End Sub
   
   
    Private Sub AboutToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AboutToolStripMenuItem.Click
        'show about window
        AboutForm.ShowDialog()
    End Sub

    Private Sub CostCalculatorForm_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        'only ONE file is created here - the file with the 3 totals
        'this event executes when the form is trying to close
        'ask the user if they wish to save their data
        'with yes/no/cancel options
        Dim answer As DialogResult
        answer = MessageBox.Show("Save changes?", "Save", MessageBoxButtons.YesNoCancel)
        If answer = DialogResult.Yes Then
            'save our list box data
            Dim ListBoxWriter As New StreamWriter("cartotals.txt")
            Dim Index As Integer = 0
            For Index = 0 To VehicleListBox.Items.Count - 1
                ListBoxWriter.WriteLine(VehicleListBox.Items(Index))

            Next
            'close the file!!!!!
            ListBoxWriter.Close()

            'save the two totals
            Dim totalswriter As New StreamWriter("smoothietotals.txt")
            totalswriter.WriteLine(total_rentals)
            totalswriter.WriteLine(total_mileage)
            totalswriter.WriteLine(totalreceipts)
            totalswriter.Close()

        End If
        If answer = DialogResult.Cancel Then
            e.Cancel = True

        End If

    End Sub

    Private Sub CalculateToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CalculateToolStripMenuItem.Click
        Dim daysrented As Integer
        Dim beginning_odometer_reading As Decimal
        Dim ending_odometer_reading As Decimal
        Dim miles_driven As Decimal
        Dim customer_charge As Decimal
        Dim daily_rate As Decimal

        Dim fileWriter As New StreamWriter("carrentaltotals.txt")
        fileWriter.Close()
        miles_driven = CDec(TotalMilesLabel.Text)
        customer_charge = CDec(CustomerChargeLabel.Text)

        Try
            If daysrented > 0 Then
                If VehicleListBox.SelectedIndex >= 0 Then
                    If beginning_odometer_reading >= ending_odometer_reading Then
                        If VehicleListBox.SelectedIndex = 0 Then
                            daily_rate = COMPACT_RATE
                        ElseIf VehicleListBox.SelectedIndex = 1 Then
                            daily_rate = MIDSIZE_RATE
                        ElseIf VehicleListBox.SelectedIndex = 2 Then
                            daily_rate = PREMIUN_RATE
                        ElseIf VehicleListBox.SelectedIndex = 3 Then
                            daily_rate = MINIVAN_RATE
                        ElseIf VehicleListBox.SelectedIndex = 4 Then
                            daily_rate = SUV_RATE
                        Else
                            MessageBox.Show("please make a selection")
                        End If

                        'diplay
                        DaysTextBox.Text = daysrented.ToString
                        EndingTextBox.Text = ending_odometer_reading.ToString
                        BeginningTextBox.Text = beginning_odometer_reading.ToString

                        'calculations

                        miles_driven = ending_odometer_reading - beginning_odometer_reading
                        MILEAGE_RATE = 0.5D * miles_driven
                        customer_charge = miles_driven * MILEAGE_RATE + daysrented * daily_rate


                        'these are our accumulating values
                        total_rentals += total_rentals
                        total_mileage += miles_driven
                        totalreceipts += customer_charge
                    Else MessageBox.Show("ending mileage must be greater than or equal to beginning mileage")
                    End If
                Else MessageBox.Show("please select a car")
                End If
            End If
        Catch ex As Exception

        End Try


    End Sub

    Private Sub ShowTotalsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ShowTotalsToolStripMenuItem.Click
        SummaryForm.ShowDialog()
    End Sub
End Class
