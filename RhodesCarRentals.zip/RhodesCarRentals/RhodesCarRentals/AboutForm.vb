﻿'About Window for Rhodes Car Rental project
Public Class AboutForm

    Private Sub CloseAboutFormButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CloseAboutFormButton.Click
        'close this window
        Close()

    End Sub
End Class